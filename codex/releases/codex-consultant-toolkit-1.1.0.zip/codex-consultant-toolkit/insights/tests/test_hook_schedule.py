import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "hooks"))
import codex_session_hook as hook

class HookScheduleTests(unittest.TestCase):
    def test_insights_is_disabled_by_default(self):
        messages = []
        with patch.dict(os.environ, {}, clear=True): hook.handle_event({"prompt": "/insights"}, emit=messages.append)
        self.assertIn("deaktiviert", messages[0])
    def test_insights_neu_uses_active_generator_when_enabled(self):
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw); generator = root / "codex_insights.py"; generator.touch(); report = root / "report.html"; report.touch(); calls = []
            def runner(command, **kwargs): calls.append(command); return subprocess.CompletedProcess(command, 0, stdout=f"{report}\n", stderr="")
            with patch.dict(os.environ, {"CODEX_TOOLKIT_ENABLE_INSIGHTS": "1"}), patch.object(hook, "GENERATOR", generator), patch.object(hook, "REPORT_DIR", root): hook.handle_event({"prompt": "/insights neu"}, runner=runner, emit=lambda _: None)
            self.assertIn("--active", calls[0]); self.assertIn("--force-research-refresh", calls[0])
    def test_failed_insights_reports_failure(self):
        with tempfile.TemporaryDirectory() as raw:
            generator = Path(raw) / "codex_insights.py"; generator.touch(); messages = []
            with patch.dict(os.environ, {"CODEX_TOOLKIT_ENABLE_INSIGHTS": "1"}), patch.object(hook, "GENERATOR", generator): hook.handle_event({"prompt": "/insights"}, runner=lambda *a, **k: subprocess.CompletedProcess(a[0], 1, "", ""), emit=messages.append)
            self.assertIn("konnte nicht", messages[0])
    def test_session_end_emits_handoff_trigger(self):
        messages = []
        with patch.object(hook, "CODEX_HOME", Path("/not-installed")): hook.handle_event({"prompt": "Ende für heute"}, emit=messages.append)
        self.assertIn("HANDOFF-TRIGGER", messages[0])
