import json
import sys
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from codex_insights import DEFAULT_CLAUDE_ROOT, main, render_report, run_report
from insight_state import InsightStore, Snapshot


class GeneratorFlowTests(unittest.TestCase):
    def write_session(self, root: Path, project: Path) -> None:
        path = root / "2026" / "09" / "session.jsonl"
        path.parent.mkdir(parents=True)
        path.write_text(
            "\n".join((
                json.dumps({"payload": {"type": "session_meta", "timestamp": "2026-09-01T08:00:00+00:00", "cwd": str(project)}}),
                json.dumps({"payload": {"type": "message", "role": "user", "content": [{"text": "Please debug the broken integration."}]}}),
            )) + "\n",
            encoding="utf-8",
        )

    def test_scheduled_writes_snapshot_gap_and_research_todo_without_marking_viewed(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            sessions, state, output, claude = (root / name for name in ("sessions", "state", "reports", "claude"))
            project = root / "private-project"
            project.mkdir()
            self.write_session(sessions, project)
            facets = claude / "facets"
            facets.mkdir(parents=True)
            (facets / "summary.json").write_text(json.dumps({"friction_counts": {"buggy_code": 2}}), encoding="utf-8")
            now = datetime(2026, 9, 1, 12, tzinfo=timezone.utc)
            store = InsightStore(state)
            store.save_snapshot(Snapshot("old", now - timedelta(days=16), "scheduled", {}, [], {}, [], []))
            store._atomic_write(state / "state.json", {"last_viewed_report_id": None, "last_viewed_on": None, "last_scheduled_at": (now - timedelta(days=16)).isoformat()})

            result = run_report("scheduled", output, state, sessions, claude, now, lambda _query: (_ for _ in ()).throw(OSError("offline")), root / "profile.json")

            self.assertTrue(result["html_path"].exists())
            self.assertEqual(result["snapshot"].kind, "scheduled")
            self.assertIsNone(InsightStore(state).state()["last_viewed_report_id"])
            self.assertEqual(InsightStore(state).state()["last_scheduled_at"], "2026-09-01T12:00:00+00:00")
            self.assertEqual(result["snapshot"].gaps[0]["kind"], "scheduled_run_late")
            self.assertIn({"status": "open", "message": "Research sources could not be refreshed."}, result["todos"])
            self.assertNotIn(str(project), result["html_path"].read_text(encoding="utf-8"))

    def test_active_synthesizes_three_snapshots_and_marks_viewed_after_artifacts_exist(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            sessions, state, output, claude = (root / name for name in ("sessions", "state", "reports", "claude"))
            project = root / "private-project"
            project.mkdir()
            self.write_session(sessions, project)
            now = datetime(2026, 9, 1, 12, tzinfo=timezone.utc)
            store = InsightStore(state)
            for offset, count in ((2, 1), (1, 2)):
                store.save_snapshot(Snapshot(f"old-{offset}", now - timedelta(days=offset), "scheduled", {"sessions": count}, [], {}, [], []))

            result = run_report("active", output, state, sessions, claude, now, lambda _query: [], root / "profile.json")

            html = result["html_path"].read_text(encoding="utf-8")
            self.assertIn("Vorher", html)
            self.assertIn("Nachher", html)
            self.assertIn("Recherche", html)
            self.assertEqual(len(result["comparison"]["snapshots"]), 3)
            self.assertEqual(InsightStore(state).state()["last_viewed_report_id"], result["snapshot"].report_id)
            self.assertTrue((state / "snapshots" / f"{result['snapshot'].report_id}.json").exists())

    def test_scheduled_gap_uses_state_timestamp_not_latest_snapshot_and_merges_todos(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            sessions, state, output, claude = (root / name for name in ("sessions", "state", "reports", "claude"))
            project = root / "project"
            project.mkdir()
            self.write_session(sessions, project)
            now = datetime(2026, 9, 1, 12, tzinfo=timezone.utc)
            store = InsightStore(state)
            store.save_snapshot(Snapshot("old", now - timedelta(days=30), "scheduled", {}, [], {}, [], []))
            store._atomic_write(state / "state.json", {"last_viewed_report_id": None, "last_viewed_on": None, "last_scheduled_at": (now - timedelta(days=2)).isoformat()})
            store._atomic_write(state / "todos.json", [{"status": "open", "message": "Keep me."}])

            result = run_report("scheduled", output, state, sessions, claude, now, lambda _query: [], root / "profile.json")

            self.assertEqual(result["snapshot"].gaps, [])
            self.assertIn({"status": "open", "message": "Keep me."}, json.loads((state / "todos.json").read_text()))

    def test_active_comparison_keeps_all_three_baselines_and_reports_restricted_metrics(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            sessions, state, output, claude = (root / name for name in ("sessions", "state", "reports", "claude"))
            project = root / "project"
            project.mkdir()
            self.write_session(sessions, project)
            now = datetime(2026, 9, 1, 12, tzinfo=timezone.utc)
            store = InsightStore(state)
            store._atomic_write(state / "state.json", {"last_viewed_report_id": None, "last_viewed_on": None, "last_scheduled_at": None})
            for offset in (3, 2, 1):
                store.save_snapshot(Snapshot(f"old-{offset}", now - timedelta(days=offset), "scheduled", {"sessions": offset}, [], {}, [], []))

            result = run_report("active", output, state, sessions, claude, now, lambda _query: [], root / "profile.json")

            self.assertEqual([item["report_id"] for item in result["comparison"]["snapshots"]], ["old-3", "old-2", "old-1"])
            self.assertEqual(result["comparison"]["baseline_status"], "restricted")
            self.assertEqual(set(result["comparison"]["current_metrics"]), {"sessions", "prompts", "tools", "projects", "claude_friction", "project_signals"})

    def test_scheduled_failure_rolls_back_all_artifacts_and_removes_partial_html(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            sessions, state, output, claude = (root / name for name in ("sessions", "state", "reports", "claude"))
            project = root / "project"
            project.mkdir()
            self.write_session(sessions, project)
            now = datetime(2026, 9, 1, 12, tzinfo=timezone.utc)
            store = InsightStore(state)
            store._atomic_write(state / "state.json", {"last_viewed_report_id": None, "last_viewed_on": None, "last_scheduled_at": None})
            store._atomic_write(state / "todos.json", [{"status": "open", "message": "Keep me."}])
            store._atomic_write(state / "research.json", [{"url": "https://example.test/old"}])
            store.save_snapshot(Snapshot("old", now - timedelta(days=1), "scheduled", {}, [], {}, [], []))
            before = {
                path.relative_to(root): path.read_bytes()
                for path in (state / "state.json", state / "todos.json", state / "research.json", state / "snapshots" / "old.json")
            }

            def partial_write(path, _document):
                path.write_text("partial", encoding="utf-8")
                raise OSError("disk full")

            with patch("codex_insights._write_html", side_effect=partial_write), self.assertRaises(OSError):
                run_report("scheduled", output, state, sessions, claude, now, lambda _query: [], root / "profile.json")

            after = {
                path.relative_to(root): path.read_bytes()
                for path in (state / "state.json", state / "todos.json", state / "research.json", state / "snapshots" / "old.json")
            }
            self.assertEqual(after, before)
            self.assertEqual(list((state / "snapshots").glob("*.json")), [state / "snapshots" / "old.json"])
            self.assertEqual(list(output.glob("*.html")), [])

    def test_missing_state_seeds_one_legacy_baseline_once(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            sessions, state, output, claude = (root / name for name in ("sessions", "state", "reports", "claude"))
            project = root / "project"
            project.mkdir()
            self.write_session(sessions, project)
            now = datetime(2026, 9, 1, 12, tzinfo=timezone.utc)

            first = run_report("active", output, state, sessions, claude, now, lambda _query: [], root / "profile.json")
            second = run_report("active", output, state, sessions, claude, now + timedelta(minutes=1), lambda _query: [], root / "profile.json")
            legacy = [snapshot for snapshot in InsightStore(state).latest_snapshots(10) if snapshot.report_id == "legacy-20260831"]

            self.assertEqual(len(legacy), 1)
            self.assertEqual(legacy[0].generated_at, datetime(2026, 8, 31, tzinfo=timezone.utc))
            self.assertEqual(first["comparison"]["baseline_status"], "nicht belastbar")
            self.assertNotEqual(second["snapshot"].report_id, "legacy-20260831")

    def test_cli_default_claude_root_is_usage_data_and_html_exposes_only_allowed_comparison_counts(self):
        self.assertEqual(DEFAULT_CLAUDE_ROOT, Path.home() / ".claude" / "usage-data")
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            sessions, state, output, claude = (root / name for name in ("sessions", "state", "reports", "claude"))
            project = root / "project"
            project.mkdir()
            self.write_session(sessions, project)
            facets = claude / "facets"
            facets.mkdir(parents=True)
            (facets / "summary.json").write_text(json.dumps({"friction_counts": {"buggy_code": 2}}), encoding="utf-8")

            result = run_report("active", output, state, sessions, claude, datetime(2026, 9, 1, 12, tzinfo=timezone.utc), lambda _query: [], root / "profile.json")
            html = result["html_path"].read_text(encoding="utf-8")

            self.assertIn("Prompts", html)
            self.assertIn("Tool-Aufrufe", html)
            self.assertIn("Claude-Reibungssignale", html)
            self.assertIn("Projekt-Signale", html)
            self.assertNotIn(str(project), html)

    def test_active_failure_rolls_back_all_artifacts_and_removes_partial_html(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            sessions, state, output, claude = (root / name for name in ("sessions", "state", "reports", "claude"))
            project = root / "project"
            project.mkdir()
            self.write_session(sessions, project)
            facets = claude / "facets"
            facets.mkdir(parents=True)
            (facets / "summary.json").write_text(json.dumps({"friction_counts": {"buggy_code": 2}}), encoding="utf-8")
            state.mkdir()
            paths = {
                "state": state / "state.json",
                "todos": state / "todos.json",
                "research": state / "research.json",
            }
            paths["state"].write_text(json.dumps({"last_viewed_report_id": None, "last_viewed_on": None, "last_scheduled_at": None}), encoding="utf-8")
            paths["todos"].write_text(json.dumps([{"status": "open", "message": "Keep me."}]), encoding="utf-8")
            paths["research"].write_text(json.dumps([{"url": "https://example.test/old", "title": "Old", "topic": "software debugging best practices", "found_at": "old", "freshness": "verified", "query": "software debugging best practices"}]), encoding="utf-8")
            store = InsightStore(state)
            now = datetime(2026, 9, 1, 12, tzinfo=timezone.utc)
            store.save_snapshot(Snapshot("old", now - timedelta(days=1), "scheduled", {}, [], {}, [], []))
            before = {name: path.read_bytes() for name, path in paths.items()}
            snapshot_before = (state / "snapshots" / "old.json").read_bytes()

            def partial_write(path, _document):
                path.write_text("partial", encoding="utf-8")
                raise OSError("disk full")

            with patch("codex_insights._write_html", side_effect=partial_write), self.assertRaises(OSError):
                run_report("active", output, state, sessions, claude, now, lambda _query: [{"url": "https://example.test/new", "title": "New"}], root / "profile.json", force_research_refresh=True)

            self.assertEqual({name: path.read_bytes() for name, path in paths.items()}, before)
            self.assertEqual((state / "snapshots" / "old.json").read_bytes(), snapshot_before)
            self.assertEqual(list((state / "snapshots").glob("*.json")), [state / "snapshots" / "old.json"])
            self.assertEqual(list(output.glob("*.html")), [])

    def test_report_privacy_wording_allows_only_generic_public_research_queries(self):
        html = render_report(
            [], datetime(2026, 9, 1, 12, tzinfo=timezone.utc), "Aktive Auswertung",
            {"audience": "geschäftlich orientiert", "explanation_style": "klar", "decision_preference": "klar"},
            {"projects": [], "comparison": {}, "research": []},
        )

        self.assertIn("keine Prompts oder Projektdaten", html)
        self.assertIn("freigegebene Rechercheanfragen", html)
        self.assertIn("Analyse, Prompts und Projektdaten bleiben lokal", html)
        self.assertIn("/insights neu", html)

    def test_force_research_refresh_is_accepted_only_for_active_cli_runs(self):
        with patch("codex_insights.sys.argv", ["codex_insights.py", "--scheduled", "--force-research-refresh"]), self.assertRaises(SystemExit) as error:
            main()
        self.assertEqual(error.exception.code, 2)

        result = {"html_path": Path("/tmp/report.html"), "snapshot": SimpleNamespace(metrics={"sessions": 0}, kind="active")}
        with patch("codex_insights.run_report", return_value=result) as runner, patch("codex_insights.sys.argv", ["codex_insights.py", "--active", "--force-research-refresh"]):
            self.assertEqual(main(), 0)
        self.assertTrue(runner.call_args.kwargs["force_research_refresh"])


if __name__ == "__main__":
    unittest.main()
