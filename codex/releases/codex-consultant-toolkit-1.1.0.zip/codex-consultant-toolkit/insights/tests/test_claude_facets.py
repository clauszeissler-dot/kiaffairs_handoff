import json
import tempfile
import unittest
from pathlib import Path

import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from claude_facets import load_claude_summary


class ClaudeFacetsTests(unittest.TestCase):
    def write_facet(self, directory: Path, name: str, value: object) -> None:
        directory.mkdir(parents=True, exist_ok=True)
        path = directory / name
        if isinstance(value, bytes):
            path.write_bytes(value)
        else:
            path.write_text(json.dumps(value), encoding="utf-8")

    def test_aggregates_allowlisted_fields_and_excludes_sensitive_text(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.write_facet(
                root / "facets",
                "one.json",
                {
                    "goal_categories": {"delivery": 2},
                    "user_satisfaction_counts": {"satisfied": 1},
                    "friction_counts": {"setup": 3},
                    "outcome": "completed",
                    "session_type": "implementation",
                    "claude_helpfulness": "high",
                    "first_prompt": "SECRET PROMPT",
                    "project_path": "/secret/project",
                    "underlying_goal": "SECRET GOAL",
                    "brief_summary": "SECRET SUMMARY",
                    "friction_detail": "SECRET DETAIL",
                    "session_id": "SECRET SESSION",
                    "unknown": "SECRET UNKNOWN",
                },
            )

            summary = load_claude_summary(root)

            self.assertEqual(
                summary,
                {
                    "goal_categories": {"delivery": 2},
                    "user_satisfaction_counts": {"satisfied": 1},
                    "friction_counts": {"setup": 3},
                    "outcome": {"completed": 1},
                    "session_type": {"implementation": 1},
                    "claude_helpfulness": {"high": 1},
                },
            )
            serialized = json.dumps(summary)
            for secret in ("SECRET", "/secret/project", "unknown"):
                self.assertNotIn(secret, serialized)

    def test_aggregates_counters_and_labels_across_two_valid_facets(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            facets = root / "facets"
            self.write_facet(
                facets,
                "one.json",
                {
                    "goal_categories": {"delivery": 2, "research": 1},
                    "user_satisfaction_counts": {"satisfied": 1},
                    "friction_counts": {"setup": 3},
                    "outcome": "completed",
                    "session_type": "implementation",
                    "claude_helpfulness": "high",
                },
            )
            self.write_facet(
                facets,
                "two.json",
                {
                    "goal_categories": {"delivery": 4},
                    "user_satisfaction_counts": {"satisfied": 2, "unsatisfied": 1},
                    "friction_counts": {"setup": 1, "handoff": 2},
                    "outcome": "completed",
                    "session_type": "review",
                    "claude_helpfulness": "medium",
                },
            )

            self.assertEqual(
                load_claude_summary(root),
                {
                    "goal_categories": {"delivery": 6, "research": 1},
                    "user_satisfaction_counts": {"satisfied": 3, "unsatisfied": 1},
                    "friction_counts": {"setup": 4, "handoff": 2},
                    "outcome": {"completed": 2},
                    "session_type": {"implementation": 1, "review": 1},
                    "claude_helpfulness": {"high": 1, "medium": 1},
                },
            )

    def test_malformed_facets_are_skipped_without_blocking_valid_data(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            facets = root / "facets"
            self.write_facet(facets, "broken.json", b"{not json")
            self.write_facet(facets, "list.json", ["not", "a", "dict"])
            self.write_facet(facets, "valid.json", {"goal_categories": {"delivery": 1}, "outcome": "done"})

            self.assertEqual(load_claude_summary(root)["goal_categories"], {"delivery": 1})
            self.assertEqual(load_claude_summary(root)["outcome"], {"done": 1})

    def test_invalid_counter_values_and_empty_labels_are_ignored(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.write_facet(
                root / "facets",
                "invalid.json",
                {
                    "goal_categories": {"negative": -1, "bool": True, "float": 1.5, "valid": 2},
                    "user_satisfaction_counts": {"negative": -4, "bool": False, "valid": 1},
                    "friction_counts": {"": 7, "text": "3", "valid": 2},
                    "outcome": "",
                    "session_type": 3,
                    "claude_helpfulness": "useful",
                },
            )

            summary = load_claude_summary(root)
            self.assertEqual(summary["goal_categories"], {"valid": 2})
            self.assertEqual(summary["user_satisfaction_counts"], {"valid": 1})
            self.assertEqual(summary["friction_counts"], {"valid": 2})
            self.assertEqual(summary["outcome"], {})
            self.assertEqual(summary["session_type"], {})
            self.assertEqual(summary["claude_helpfulness"], {"useful": 1})

    def test_missing_facets_directory_returns_all_empty_plain_dicts(self):
        with tempfile.TemporaryDirectory() as directory:
            summary = load_claude_summary(Path(directory))
            self.assertEqual(set(summary), {"goal_categories", "user_satisfaction_counts", "friction_counts", "outcome", "session_type", "claude_helpfulness"})
            self.assertTrue(all(type(value) is dict for value in summary.values()))

    def test_output_order_is_deterministic(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            facets = root / "facets"
            self.write_facet(facets, "z-last.json", {"goal_categories": {"zulu": 1, "alpha": 2}, "outcome": "zulu"})
            self.write_facet(facets, "a-first.json", {"goal_categories": {"middle": 3, "alpha": 4}, "outcome": "alpha"})

            summary = load_claude_summary(root)

            self.assertEqual(list(summary["goal_categories"]), ["alpha", "middle", "zulu"])
            self.assertEqual(list(summary["outcome"]), ["alpha", "zulu"])


if __name__ == "__main__":
    unittest.main()
