import hashlib
import json
import os
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import project_observer
from project_observer import observe_projects


class ProjectObserverTests(unittest.TestCase):
    def create_project(self, root: Path) -> Path:
        root.mkdir()
        subprocess.run(["git", "init", "--quiet", str(root)], check=True)
        return root

    def snapshot(self, root: Path) -> dict[str, bytes]:
        return {
            str(path.relative_to(root)): path.read_bytes()
            for path in root.rglob("*")
            if path.is_file() and ".git" not in path.parts
        }

    def snapshot_all(self, root: Path) -> dict[str, bytes]:
        return {
            str(path.relative_to(root)): path.read_bytes()
            for path in root.rglob("*")
            if path.is_file()
        }

    def test_observes_allowlisted_documents_without_exposing_paths_or_text(self):
        with tempfile.TemporaryDirectory() as directory:
            project = self.create_project(Path(directory) / "sensitive-project")
            handoff = project / "docs" / "handoffs" / "20260901_01_status.md"
            handoff.parent.mkdir(parents=True)
            handoff.write_text(
                "# Status\n\n## Offene Folgeschritte\n\n1. Keep this private.\n2. Also private.\n\n## Verifikation\n\n- [x] Private verification detail.\n",
                encoding="utf-8",
            )
            subprocess.run(["git", "-C", str(project), "add", "docs/handoffs/20260901_01_status.md"], check=True)
            subprocess.run(
                ["git", "-C", str(project), "-c", "user.name=Test", "-c", "user.email=test@example.com", "commit", "--quiet", "-m", "status"],
                check=True,
            )
            before = self.snapshot(project)

            observed = observe_projects(codex_cwds=[str(project)], claude_session_meta_paths=[])

            self.assertEqual(len(observed), 1)
            self.assertEqual(
                observed[0],
                {
                    "project_key": hashlib.sha256(str(project.resolve()).encode("utf-8")).hexdigest(),
                    "has_status_document": False,
                    "document_count": 1,
                    "open_follow_steps": 2,
                    "verification_markers": 1,
                    "latest_document_mtime": handoff.stat().st_mtime,
                    "git_worktree_dirty": False,
                },
            )
            self.assertEqual(self.snapshot(project), before)
            serialized = json.dumps(observed)
            self.assertNotIn(str(project), serialized)
            self.assertNotIn("Keep this private", serialized)
            self.assertNotIn("Private verification", serialized)

    def test_discovery_deduplicates_codex_cwds_and_claude_project_paths(self):
        with tempfile.TemporaryDirectory() as directory:
            project = self.create_project(Path(directory) / "project")
            nested = project / "nested"
            nested.mkdir()
            metadata = Path(directory) / "session-meta.json"
            metadata.write_text(json.dumps({"project_path": str(project)}), encoding="utf-8")

            observed = observe_projects(
                codex_cwds=[str(project), str(nested)],
                claude_session_meta_paths=[metadata],
            )

            self.assertEqual(observed, [
                {
                    "project_key": hashlib.sha256(str(project.resolve()).encode("utf-8")).hexdigest(),
                    "has_status_document": False,
                    "document_count": 0,
                    "open_follow_steps": 0,
                    "verification_markers": 0,
                    "latest_document_mtime": None,
                    "git_worktree_dirty": False,
                }
            ])

    def test_malformed_session_metadata_is_ignored_safely(self):
        with tempfile.TemporaryDirectory() as directory:
            metadata = Path(directory) / "broken-session-meta.json"
            metadata.write_text("{not json", encoding="utf-8")

            self.assertEqual(observe_projects(codex_cwds=[None, 4, ""], claude_session_meta_paths=[metadata]), [])

    def test_non_git_project_has_unknown_worktree_state(self):
        with tempfile.TemporaryDirectory() as directory:
            project = Path(directory) / "project"
            project.mkdir()

            observed = observe_projects(codex_cwds=[str(project)], claude_session_meta_paths=[])

            self.assertIsNone(observed[0]["git_worktree_dirty"])

    def test_reports_dirty_git_worktree_without_writing_to_project(self):
        with tempfile.TemporaryDirectory() as directory:
            project = self.create_project(Path(directory) / "project")
            tracked = project / "tracked.txt"
            tracked.write_text("original", encoding="utf-8")
            subprocess.run(["git", "-C", str(project), "add", "tracked.txt"], check=True)
            subprocess.run(
                ["git", "-C", str(project), "-c", "user.name=Test", "-c", "user.email=test@example.com", "commit", "--quiet", "-m", "initial"],
                check=True,
            )
            tracked.write_text("changed", encoding="utf-8")
            before = self.snapshot(project)

            observed = observe_projects(codex_cwds=[str(project)], claude_session_meta_paths=[])

            self.assertTrue(observed[0]["git_worktree_dirty"])
            self.assertEqual(self.snapshot(project), before)

    def test_git_status_disables_optional_locks_and_fsmonitor_without_touching_git_data(self):
        with tempfile.TemporaryDirectory() as directory:
            project = self.create_project(Path(directory) / "project")
            git_before = self.snapshot_all(project / ".git")
            calls = []

            def run(command, **kwargs):
                calls.append((command, kwargs))
                if command[-2:] == ["rev-parse", "--show-toplevel"]:
                    return subprocess.CompletedProcess(command, 0, f"{project}\n", "")
                return subprocess.CompletedProcess(command, 0, "", "")

            with patch("project_observer.subprocess.run", side_effect=run):
                observed = observe_projects(codex_cwds=[str(project)], claude_session_meta_paths=[])

            self.assertFalse(observed[0]["git_worktree_dirty"])
            self.assertIn(
                (
                    ["git", "--no-optional-locks", "-c", "core.fsmonitor=false", "-C", str(project.resolve()), "status", "--porcelain"],
                    {"check": False, "capture_output": True, "text": True, "timeout": 2},
                ),
                calls,
            )
            self.assertEqual(self.snapshot_all(project / ".git"), git_before)

    def test_document_descriptor_open_race_is_skipped_safely(self):
        with tempfile.TemporaryDirectory() as directory:
            project = self.create_project(Path(directory) / "project")
            document = project / "docs" / "handoffs" / "status.md"
            document.parent.mkdir(parents=True)
            document.write_text("# Status", encoding="utf-8")
            original_open = os.open

            def open_document(path, *args, **kwargs):
                if Path(path).name == "status.md":
                    raise OSError("document disappeared")
                return original_open(path, *args, **kwargs)

            with patch("project_observer.os.open", side_effect=open_document):
                observed = observe_projects(codex_cwds=[str(project)], claude_session_meta_paths=[])

            self.assertEqual(observed[0]["document_count"], 0)
            self.assertIsNone(observed[0]["latest_document_mtime"])

    def test_docs_root_symlink_is_not_enumerated_outside_the_project(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            project = self.create_project(root / "project")
            external_docs = root / "external-docs"
            external_docs.mkdir()
            (external_docs / "private.md").write_text("## Verifikation\n- [x] EXTERNAL DOCS ROOT", encoding="utf-8")
            (project / "docs").symlink_to(external_docs, target_is_directory=True)

            observed = observe_projects(codex_cwds=[str(project)], claude_session_meta_paths=[])

            self.assertEqual(observed[0]["document_count"], 0)
            self.assertNotIn("EXTERNAL DOCS ROOT", json.dumps(observed))

    def test_docs_child_directory_symlink_is_not_enumerated_outside_the_project(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            project = self.create_project(root / "project")
            external_docs = root / "external-docs"
            external_docs.mkdir()
            (external_docs / "private.md").write_text("## Verifikation\n- [x] EXTERNAL CHILD", encoding="utf-8")
            docs = project / "docs"
            docs.mkdir()
            (docs / "child").symlink_to(external_docs, target_is_directory=True)

            observed = observe_projects(codex_cwds=[str(project)], claude_session_meta_paths=[])

            self.assertEqual(observed[0]["document_count"], 0)
            self.assertNotIn("EXTERNAL CHILD", json.dumps(observed))

    def test_observes_fixed_root_documents_and_bounded_docs_markdown_locations(self):
        with tempfile.TemporaryDirectory() as directory:
            project = self.create_project(Path(directory) / "project")
            documents = [
                project / "STATUS.md",
                project / "README.md",
                project / "AGENTS.md",
                project / "CHANGELOG.md",
                project / "docs" / "one.md",
                project / "docs" / "nested" / "two.md",
                project / "docs" / "handoffs" / "three.md",
            ]
            for document in documents:
                document.parent.mkdir(parents=True, exist_ok=True)
                document.write_text("# Known document", encoding="utf-8")

            observed = observe_projects(codex_cwds=[str(project)], claude_session_meta_paths=[])

            self.assertEqual(observed[0]["document_count"], len(documents))
            self.assertTrue(observed[0]["has_status_document"])

    def test_excludes_documents_deeper_than_three_levels_under_docs(self):
        with tempfile.TemporaryDirectory() as directory:
            project = self.create_project(Path(directory) / "project")
            included = project / "docs" / "one" / "two" / "included.md"
            excluded = project / "docs" / "one" / "two" / "three" / "excluded.md"
            included.parent.mkdir(parents=True)
            excluded.parent.mkdir(parents=True)
            included.write_text("# Included", encoding="utf-8")
            excluded.write_text("# Excluded", encoding="utf-8")

            observed = observe_projects(codex_cwds=[str(project)], claude_session_meta_paths=[])

            self.assertEqual(observed[0]["document_count"], 1)

    def test_caps_known_documents_at_one_hundred(self):
        with tempfile.TemporaryDirectory() as directory:
            project = self.create_project(Path(directory) / "project")
            docs = project / "docs"
            docs.mkdir()
            for number in range(105):
                (docs / f"{number:03}.md").write_text("# Document", encoding="utf-8")

            observed = observe_projects(codex_cwds=[str(project)], claude_session_meta_paths=[])

            self.assertEqual(observed[0]["document_count"], 100)

    def test_caps_document_reads_at_64_kib_without_exposing_truncated_text(self):
        with tempfile.TemporaryDirectory() as directory:
            project = self.create_project(Path(directory) / "project")
            document = project / "docs" / "handoffs" / "oversize.md"
            document.parent.mkdir(parents=True)
            prefix = b"## Verifikation\n- [x] counted\n"
            document.write_bytes(prefix + b"p" * (65536 - len(prefix)) + b"\n- [x] PRIVATE AFTER CAP\n")

            observed = observe_projects(codex_cwds=[str(project)], claude_session_meta_paths=[])

            self.assertEqual(observed[0]["verification_markers"], 1)
            self.assertNotIn("PRIVATE AFTER CAP", json.dumps(observed))

    def test_rejects_document_symlinks_without_reading_their_targets(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            project = self.create_project(root / "project")
            private_document = root / "private.md"
            private_document.write_text("## Verifikation\n- [x] PRIVATE SYMLINK CONTENT", encoding="utf-8")
            link = project / "docs" / "link.md"
            link.parent.mkdir()
            link.symlink_to(private_document)
            original_open = Path.open

            def open_document(path, *args, **kwargs):
                if path.name == "link.md":
                    raise AssertionError("symlink target was read")
                return original_open(path, *args, **kwargs)

            with patch.object(Path, "open", open_document):
                observed = observe_projects(codex_cwds=[str(project)], claude_session_meta_paths=[])

            self.assertEqual(observed[0]["document_count"], 0)
            self.assertEqual(observed[0]["verification_markers"], 0)
            self.assertNotIn("PRIVATE SYMLINK CONTENT", json.dumps(observed))

    def test_rejects_a_document_swapped_to_a_symlink_after_discovery(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            project = self.create_project(root / "project")
            document = project / "docs" / "handoffs" / "status.md"
            document.parent.mkdir(parents=True)
            document.write_text("## Verifikation\n- [x] benign", encoding="utf-8")
            private_document = root / "private.md"
            private_document.write_text("## Verifikation\n- [x] SWAPPED PRIVATE CONTENT", encoding="utf-8")

            def swap_after_discovery(_root):
                document.unlink()
                document.symlink_to(private_document)
                return [("docs", "handoffs", "status.md")]

            with patch.object(project_observer, "_known_documents", side_effect=swap_after_discovery):
                observed = observe_projects(codex_cwds=[str(project)], claude_session_meta_paths=[])

            self.assertEqual(observed[0]["document_count"], 0)
            self.assertEqual(observed[0]["verification_markers"], 0)
            self.assertNotIn("SWAPPED PRIVATE CONTENT", json.dumps(observed))

    def test_discovers_docs_without_unbounded_recursive_globbing(self):
        with tempfile.TemporaryDirectory() as directory:
            project = self.create_project(Path(directory) / "project")
            included = project / "docs" / "included.md"
            included.parent.mkdir()
            included.write_text("# Included", encoding="utf-8")
            deep = project / "docs" / "one" / "two" / "three" / "not-enumerated.md"
            deep.parent.mkdir(parents=True)
            deep.write_text("# Deep", encoding="utf-8")
            original_iterdir = Path.iterdir

            def bounded_iterdir(path):
                if path.name == "three" and path.parent.name == "two":
                    raise AssertionError("deep directory was enumerated")
                return original_iterdir(path)

            with patch.object(Path, "rglob", side_effect=AssertionError("unbounded traversal")), patch.object(Path, "iterdir", bounded_iterdir):
                observed = observe_projects(codex_cwds=[str(project)], claude_session_meta_paths=[])

            self.assertEqual(observed[0]["document_count"], 1)

    def test_stops_docs_enumeration_after_one_thousand_entries_including_empty_directories(self):
        with tempfile.TemporaryDirectory() as directory:
            project = self.create_project(Path(directory) / "project")
            docs = project / "docs"
            docs.mkdir()
            for number in range(1001):
                (docs / f"{number:04}").mkdir()

            observed = observe_projects(codex_cwds=[str(project)], claude_session_meta_paths=[])

            self.assertEqual(observed[0]["document_count"], 0)

    def test_child_directory_swap_cannot_redirect_descriptor_relative_document_open(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            project = self.create_project(root / "project")
            child = project / "docs" / "child"
            child.mkdir(parents=True)
            document = child / "status.md"
            document.write_text("## Verifikation\n- [x] trusted", encoding="utf-8")
            external = root / "external"
            external.mkdir()
            (external / "status.md").write_text(
                "## Verifikation\n- [x] PRIVATE REDIRECT\n- [x] PRIVATE REDIRECT\n",
                encoding="utf-8",
            )
            original_open = os.open
            swapped = False

            def swap_before_file_open(path, flags, *args, **kwargs):
                nonlocal swapped
                if not swapped and Path(path).name == "status.md":
                    swapped = True
                    child.rename(project / "docs" / ".held-child")
                    child.symlink_to(external, target_is_directory=True)
                return original_open(path, flags, *args, **kwargs)

            with patch("project_observer.os.open", side_effect=swap_before_file_open):
                observed = observe_projects(codex_cwds=[str(project)], claude_session_meta_paths=[])

            self.assertEqual(observed[0]["document_count"], 1)
            self.assertEqual(observed[0]["verification_markers"], 1)
            self.assertNotIn("PRIVATE REDIRECT", json.dumps(observed))


if __name__ == "__main__":
    unittest.main()
