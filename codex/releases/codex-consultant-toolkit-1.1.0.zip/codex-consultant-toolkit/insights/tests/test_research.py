import json
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path

from research import _PinnedHTTPSHandler, _SafeRedirectHandler, cache_sources, fetch_url, refresh_sources, safe_queries


class ResearchTests(unittest.TestCase):
    def test_safe_queries_maps_only_approved_categories_with_two_or_more_events(self):
        queries = safe_queries(
            {
                "wrong_approach": 2,
                "private_customer_problem": 99,
                "buggy_code": 3,
                "tool_errors": 1,
                "instruction_violation_by_subagents": 2,
            }
        )

        self.assertEqual(
            queries,
            [
                "software debugging best practices",
                "agent instruction compliance best practices",
                "software problem solving best practices",
            ],
        )
        self.assertNotIn("private_customer_problem", " ".join(queries))

    def test_safe_queries_rejects_untrusted_counts_and_is_deterministic(self):
        counts = {"tool_errors": "2", "buggy_code": 2, "unknown": 8}
        self.assertEqual(safe_queries(counts), ["software debugging best practices"])
        self.assertEqual(safe_queries(dict(reversed(list(counts.items())))), ["software debugging best practices"])

    def test_refresh_sources_marks_success_verified_and_adds_checked_at(self):
        now = datetime(2026, 9, 1, 10, 0, tzinfo=timezone.utc)

        result = refresh_sources(
            ["software debugging best practices"],
            lambda query: [{"url": "https://example.test/debug", "title": "Debug", "topic": query}],
            now=now,
        )

        self.assertEqual(
            result,
            [{
                "url": "https://example.test/debug",
                "title": "Debug",
                "topic": "software debugging best practices",
                "checked_at": "2026-09-01T10:00:00+00:00",
                "verification": "verified",
            }],
        )

    def test_refresh_sources_keeps_failures_nonfatal_and_unverified(self):
        def unavailable(_query):
            raise OSError("offline")

        result = refresh_sources(["software debugging best practices"], unavailable, now=datetime(2026, 9, 1, tzinfo=timezone.utc))

        self.assertEqual(result[0]["verification"], "unverified")
        self.assertEqual(result[0]["checked_at"], "2026-09-01T00:00:00+00:00")
        self.assertEqual(result[0]["topic"], "software debugging best practices")
        self.assertNotIn("offline", json.dumps(result))

    def test_cache_sources_persists_allowlisted_fields_and_safe_query_only(self):
        with tempfile.TemporaryDirectory() as directory:
            cache = Path(directory, "research.json")
            now = datetime(2026, 9, 1, tzinfo=timezone.utc)

            result = cache_sources(
                cache,
                {"buggy_code": 2, "secret_issue": 20},
                lambda query: [{"url": "https://example.test/debug", "title": "Debug", "body": "private", "topic": query}],
                now=now,
            )

            stored = json.loads(cache.read_text(encoding="utf-8"))
            self.assertEqual(result["todos"], [])
            self.assertEqual(stored, [{
                "url": "https://example.test/debug",
                "title": "Debug",
                "topic": "software debugging best practices",
                "found_at": "2026-09-01T00:00:00+00:00",
                "freshness": "verified",
                "query": "software debugging best practices",
            }])
            self.assertNotIn("secret_issue", json.dumps(stored))
            self.assertNotIn("private", json.dumps(stored))

    def test_cache_sources_returns_open_todo_for_network_failure(self):
        with tempfile.TemporaryDirectory() as directory:
            result = cache_sources(
                Path(directory, "research.json"),
                {"tool_errors": 2},
                lambda _query: (_ for _ in ()).throw(OSError("offline")),
                now=datetime(2026, 9, 1, tzinfo=timezone.utc),
            )

            self.assertEqual(result["sources"], [])
            self.assertEqual(result["todos"], [{"status": "open", "message": "Research sources could not be refreshed."}])

    def test_cache_sources_preserves_existing_cache_when_refresh_fails(self):
        with tempfile.TemporaryDirectory() as directory:
            cache = Path(directory, "research.json")
            existing = [{"url": "https://example.test/old", "title": "Old", "topic": "software debugging best practices", "found_at": "2026-08-01T00:00:00+00:00", "freshness": "verified", "query": "software debugging best practices"}]
            cache.write_text(json.dumps(existing), encoding="utf-8")

            result = cache_sources(
                cache,
                {"buggy_code": 2},
                lambda _query: (_ for _ in ()).throw(OSError("offline")),
                now=datetime(2026, 9, 1, tzinfo=timezone.utc),
            )

            self.assertEqual(result["sources"], existing)
            self.assertEqual(json.loads(cache.read_text(encoding="utf-8")), existing)
            self.assertEqual(result["todos"], [{"status": "open", "message": "Research sources could not be refreshed."}])

    def test_fetch_url_uses_timeout_and_user_agent(self):
        calls = []

        class Response:
            def __enter__(self):
                return self

            def __exit__(self, *_args):
                return False

            def read(self, _size):
                return b"ok"

        def opener(request, timeout):
            calls.append((request, timeout))
            return Response()

        self.assertEqual(fetch_url("https://example.test", opener=opener, resolver=lambda _host: ["8.8.8.8"]), b"ok")
        self.assertEqual(calls[0][1], 15)
        self.assertTrue(calls[0][0].get_header("User-agent"))

    def test_fetch_url_rejects_unsafe_schemes_hosts_and_private_destinations(self):
        def no_open(*_args, **_kwargs):
            self.fail("unsafe URL must not be opened")

        for url, addresses in (
            ("file:///etc/passwd", ["8.8.8.8"]),
            ("https://localhost/private", ["127.0.0.1"]),
            ("https://127.0.0.1/private", ["127.0.0.1"]),
            ("https://10.0.0.1/private", ["10.0.0.1"]),
            ("https://user:pass@example.test/private", ["8.8.8.8"]),
        ):
            with self.subTest(url=url), self.assertRaises(ValueError):
                fetch_url(url, opener=no_open, resolver=lambda _host, addresses=addresses: addresses)

    def test_redirect_handler_rejects_redirect_to_private_destination(self):
        handler = _SafeRedirectHandler(lambda _host: ["127.0.0.1"])

        with self.assertRaises(ValueError):
            handler.redirect_request(
                __import__("urllib.request", fromlist=["Request"]).Request("https://example.test"),
                None,
                302,
                "Found",
                {},
                "https://127.0.0.1/admin",
            )

    def test_pinned_https_handler_connects_to_validated_address_without_reresolving(self):
        calls = []

        def resolver(_host):
            calls.append("resolved")
            return ["8.8.8.8"] if len(calls) == 1 else ["127.0.0.1"]

        class CapturingHandler(_PinnedHTTPSHandler):
            def do_open(self, connection_factory, request, **kwargs):
                return connection_factory(request.host, timeout=15, **kwargs)

        connection = CapturingHandler(resolver).https_open(__import__("urllib.request", fromlist=["Request"]).Request("https://example.test/path"))

        self.assertEqual(calls, ["resolved"])
        self.assertEqual(connection.connect_hosts, ("8.8.8.8",))
        self.assertEqual(connection.host, "example.test")

    def test_fetch_url_rejects_responses_larger_than_one_megabyte(self):
        class Response:
            def __enter__(self):
                return self

            def __exit__(self, *_args):
                return False

            def read(self, _size):
                return b"x" * (1024 * 1024 + 1)

        with self.assertRaises(ValueError):
            fetch_url("https://example.test", opener=lambda *_args, **_kwargs: Response(), resolver=lambda _host: ["8.8.8.8"])


if __name__ == "__main__":
    unittest.main()
