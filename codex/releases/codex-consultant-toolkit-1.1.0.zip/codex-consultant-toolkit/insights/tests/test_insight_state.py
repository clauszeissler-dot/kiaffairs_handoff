import json
import tempfile
import unittest
from dataclasses import replace
from datetime import datetime, timedelta, timezone
from pathlib import Path

from insight_state import InsightStore, Snapshot


def snapshot(report_id: str, day: int) -> Snapshot:
    return Snapshot(
        report_id=report_id,
        generated_at=datetime(2026, 8, 1, tzinfo=timezone.utc).replace(day=day),
        kind="weekly",
        metrics={"score": day},
        recommendations=["keep going"],
        comparison={},
        gaps=[],
        research_ids=[],
    )


class InsightStateTests(unittest.TestCase):
    def test_latest_snapshots_returns_newest_three_in_chronological_order(self):
        with tempfile.TemporaryDirectory() as directory:
            store = InsightStore(directory)
            store.save_snapshot(snapshot("snapshot-1", 1))
            store.save_snapshot(snapshot("snapshot-15", 15))
            store.save_snapshot(snapshot("snapshot-29", 29))
            store.save_snapshot(replace(snapshot("snapshot-43", 1), generated_at=datetime(2026, 9, 12, tzinfo=timezone.utc)))

            self.assertEqual(
                [item.report_id for item in store.latest_snapshots()],
                ["snapshot-15", "snapshot-29", "snapshot-43"],
            )

    def test_record_schedule_gap_creates_open_todo_after_fourteen_days(self):
        with tempfile.TemporaryDirectory() as directory:
            store = InsightStore(directory)
            previous = snapshot("snapshot-1", 1)
            gap = store.record_schedule_gap(previous, datetime(2026, 8, 20, tzinfo=timezone.utc))

            self.assertEqual(gap, {"kind": "scheduled_run_late", "from": "2026-08-01", "to": "2026-08-20", "late_by_days": 5})
            self.assertEqual(json.loads(Path(directory, "todos.json").read_text())[0], {"status": "open", "message": "Vergleichslücke im nächsten Bericht erneut prüfen."})

    def test_no_prior_or_on_time_schedule_has_no_gap(self):
        with tempfile.TemporaryDirectory() as directory:
            store = InsightStore(directory)
            self.assertIsNone(store.record_schedule_gap(None, datetime(2026, 8, 20, tzinfo=timezone.utc)))
            self.assertIsNone(store.record_schedule_gap(snapshot("old", 1), datetime(2026, 8, 15, tzinfo=timezone.utc)))

    def test_schedule_gap_uses_full_elapsed_time(self):
        with tempfile.TemporaryDirectory() as directory:
            store = InsightStore(directory)
            now = snapshot("old", 1).generated_at + timedelta(days=14, hours=23, minutes=59)
            gap = store.record_schedule_gap(snapshot("old", 1), now)
            self.assertEqual(gap["late_by_days"], 1)
            self.assertEqual(json.loads(Path(directory, "todos.json").read_text())[0]["status"], "open")

    def test_malformed_todos_are_preserved_and_recovered(self):
        with tempfile.TemporaryDirectory() as directory:
            store = InsightStore(directory)
            todos = Path(directory, "todos.json")
            original = b"not-json\n"
            todos.write_bytes(original)
            previous = snapshot("old", 1)
            gap = store.record_schedule_gap(previous, datetime(2026, 8, 20, tzinfo=timezone.utc))
            self.assertEqual(todos.read_bytes(), original)
            self.assertEqual(json.loads(Path(directory, "todos.recovered.json").read_text()), {"gap": gap, "todos": [{"status": "open", "message": "Vergleichslücke im nächsten Bericht erneut prüfen."}]})

    def test_mark_viewed_persists_utc_timestamp_and_preserves_schedule(self):
        with tempfile.TemporaryDirectory() as directory:
            store = InsightStore(directory)
            store.save_snapshot(snapshot("valid", 1))
            store._atomic_write(Path(directory, "state.json"), {"last_viewed_report_id": None, "last_viewed_on": None, "last_scheduled_at": "2026-08-01T00:00:00+00:00"})
            self.assertTrue(store.mark_viewed("valid", datetime(2026, 9, 1, 2, 30, tzinfo=timezone(timedelta(hours=2)))))
            self.assertEqual(store.state(), {"last_viewed_report_id": "valid", "last_viewed_on": "2026-09-01T00:30:00+00:00", "last_scheduled_at": "2026-08-01T00:00:00+00:00"})

    def test_state_has_defaults(self):
        with tempfile.TemporaryDirectory() as directory:
            self.assertEqual(InsightStore(directory).state(), {"last_viewed_report_id": None, "last_viewed_on": None, "last_scheduled_at": None})

    def test_unsafe_report_id_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            store = InsightStore(directory)
            for report_id in ("../state", "nested/id", ""):
                with self.subTest(report_id=report_id):
                    with self.assertRaises(ValueError):
                        store.save_snapshot(snapshot(report_id, 1))
            self.assertFalse(Path(directory, "state.json").exists())

    def test_wrong_schema_snapshot_is_ignored(self):
        with tempfile.TemporaryDirectory() as directory:
            store = InsightStore(directory)
            store.save_snapshot(snapshot("valid", 1))
            Path(directory, "snapshots", "wrong.json").write_text(json.dumps({"report_id": 42, "generated_at": "2026-08-02T00:00:00+00:00", "kind": "weekly", "metrics": [], "recommendations": {}, "comparison": {}, "gaps": [], "research_ids": []}))
            self.assertEqual([item.report_id for item in store.latest_snapshots()], ["valid"])

    def test_naive_timestamps_are_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            store = InsightStore(directory)
            with self.assertRaises(ValueError):
                store.save_snapshot(replace(snapshot("naive", 1), generated_at=datetime(2026, 8, 1)))
            with self.assertRaises(ValueError):
                store.record_schedule_gap(snapshot("valid", 1), datetime(2026, 8, 20))

    def test_marking_missing_report_does_not_change_state(self):
        with tempfile.TemporaryDirectory() as directory:
            store = InsightStore(directory)

            self.assertFalse(store.mark_viewed("missing", datetime(2026, 9, 1, tzinfo=timezone.utc)))
            self.assertIsNone(store.state()["last_viewed_report_id"])

    def test_malformed_snapshot_is_ignored(self):
        with tempfile.TemporaryDirectory() as directory:
            store = InsightStore(directory)
            store.save_snapshot(snapshot("valid", 1))
            Path(directory, "snapshots", "broken.json").write_text("{not json")

            self.assertEqual([item.report_id for item in store.latest_snapshots()], ["valid"])

    def test_persistence_is_parseable_and_leaves_no_temp_files(self):
        with tempfile.TemporaryDirectory() as directory:
            store = InsightStore(directory)
            store.save_snapshot(snapshot("valid", 1))
            store.mark_viewed("valid", datetime(2026, 9, 1, tzinfo=timezone.utc))

            json.loads(Path(directory, "state.json").read_text())
            json.loads(next(Path(directory, "snapshots").glob("*.json")).read_text())
            self.assertEqual(list(Path(directory).rglob("*.tmp")), [])


if __name__ == "__main__":
    unittest.main()
