"""Read-only, privacy-preserving summaries of known local projects."""

from __future__ import annotations

import hashlib
import json
import os
import re
import stat
import subprocess
from pathlib import Path
from typing import Any, Iterable


_OPEN_FOLLOW_HEADINGS = {"open follow steps", "offene folgeschritte"}
_VERIFICATION_HEADINGS = {"verification", "verifikation"}
_HEADING_RE = re.compile(r"^#{1,6}\s+(.+?)\s*#*\s*$")
_LIST_ITEM_RE = re.compile(r"^\s*(?:[-*+]\s+|\d+[.)]\s+)")
_CHECKED_ITEM_RE = re.compile(r"^\s*(?:[-*+]\s+|\d+[.)]\s+)\[[xX]\]\s+")
_MAX_DOCUMENTS = 100
_MAX_DOCUMENT_BYTES = 65536
_MAX_DOC_ENTRIES = 1000


def observe_projects(
    codex_cwds: Iterable[object],
    claude_session_meta_paths: Iterable[object],
) -> list[dict[str, object]]:
    """Return only aggregate fields for project roots discovered from local metadata.

    The returned values deliberately contain no project paths or document contents.
    """
    roots = _discover_project_roots(codex_cwds, claude_session_meta_paths)
    return [_observe_project(root) for root in roots]


def _discover_project_roots(
    codex_cwds: Iterable[object], claude_session_meta_paths: Iterable[object]
) -> list[Path]:
    candidates = list(codex_cwds) if _is_iterable(codex_cwds) else []
    for metadata_path in claude_session_meta_paths if _is_iterable(claude_session_meta_paths) else []:
        project_path = _project_path_from_metadata(metadata_path)
        if project_path is not None:
            candidates.append(project_path)

    roots_by_key: dict[str, Path] = {}
    for candidate in candidates:
        if not isinstance(candidate, (str, Path)) or not str(candidate):
            continue
        try:
            path = Path(candidate).expanduser().resolve()
        except (OSError, RuntimeError, ValueError):
            continue
        if not path.is_dir():
            continue
        root = _git_root(path) or path
        key = _project_key(root)
        roots_by_key.setdefault(key, root)
    return [roots_by_key[key] for key in sorted(roots_by_key)]


def _is_iterable(value: object) -> bool:
    return not isinstance(value, (str, bytes, Path)) and hasattr(value, "__iter__")


def _project_path_from_metadata(metadata_path: object) -> str | None:
    if not isinstance(metadata_path, (str, Path)):
        return None
    try:
        payload = json.loads(Path(metadata_path).read_text(encoding="utf-8"))
    except (OSError, TypeError, ValueError):
        return None
    project_path = payload.get("project_path") if isinstance(payload, dict) else None
    return project_path if isinstance(project_path, str) and project_path else None


def _git_root(path: Path) -> Path | None:
    try:
        result = subprocess.run(
            ["git", "-C", str(path), "rev-parse", "--show-toplevel"],
            check=False,
            capture_output=True,
            text=True,
            timeout=2,
        )
        root = result.stdout.strip()
        return Path(root).resolve() if result.returncode == 0 and root else None
    except (OSError, subprocess.SubprocessError, ValueError):
        return None


def _project_key(root: Path) -> str:
    return hashlib.sha256(str(root).encode("utf-8")).hexdigest()


def _observe_project(root: Path) -> dict[str, object]:
    try:
        root = root.resolve()
    except (OSError, RuntimeError):
        return _empty_observation(root)
    root_descriptor = _open_directory(root)
    if root_descriptor is None:
        return _empty_observation(root)
    try:
        documents = _known_documents(root_descriptor)
        observed_documents: list[tuple[tuple[str, ...], float, int, int]] = []
        for document in documents:
            observation = _document_observation(root_descriptor, document)
            if observation is not None:
                mtime, open_count, verification_count = observation
                observed_documents.append((document, mtime, open_count, verification_count))
    finally:
        _close_descriptor(root_descriptor)

    open_follow_steps = 0
    verification_markers = 0
    for _, _, open_count, verification_count in observed_documents:
        open_follow_steps += open_count
        verification_markers += verification_count
    return {
        "project_key": _project_key(root),
        "has_status_document": any(document == ("STATUS.md",) for document, *_ in observed_documents),
        "document_count": len(observed_documents),
        "open_follow_steps": open_follow_steps,
        "verification_markers": verification_markers,
        "latest_document_mtime": max((mtime for _, mtime, _, _ in observed_documents), default=None),
        "git_worktree_dirty": _git_worktree_dirty(root),
    }


def _empty_observation(root: Path) -> dict[str, object]:
    return {
        "project_key": _project_key(root),
        "has_status_document": False,
        "document_count": 0,
        "open_follow_steps": 0,
        "verification_markers": 0,
        "latest_document_mtime": None,
        "git_worktree_dirty": None,
    }


def _known_documents(root_descriptor: int) -> list[tuple[str, ...]]:
    existing: list[tuple[str, ...]] = []
    for name in ("STATUS.md", "README.md", "AGENTS.md", "CHANGELOG.md"):
        if _is_regular_file_at(root_descriptor, name):
            existing.append((name,))
    remaining = _MAX_DOCUMENTS - len(existing)
    if remaining:
        docs_descriptor = _open_directory_at(root_descriptor, "docs")
        if docs_descriptor is not None:
            existing.extend(_docs_markdown_paths(docs_descriptor, remaining))
    return existing


def _docs_markdown_paths(docs_descriptor: int, limit: int) -> list[tuple[str, ...]]:
    """Return Markdown files no deeper than three levels below ``docs``."""
    documents: list[tuple[str, ...]] = []
    directories: list[tuple[int, tuple[str, ...], int]] = [(docs_descriptor, ("docs",), 0)]
    entries_seen = 0
    try:
        while directories and len(documents) < limit and entries_seen < _MAX_DOC_ENTRIES:
            directory_descriptor, components, depth = directories.pop()
            try:
                with os.scandir(directory_descriptor) as entries:
                    for entry in entries:
                        if entries_seen >= _MAX_DOC_ENTRIES or len(documents) >= limit:
                            return documents
                        entries_seen += 1
                        try:
                            if entry.is_symlink():
                                continue
                            if entry.is_file(follow_symlinks=False) and entry.name.casefold().endswith(".md"):
                                documents.append((*components, entry.name))
                            elif entry.is_dir(follow_symlinks=False) and depth < 2:
                                child_descriptor = _open_directory_at(directory_descriptor, entry.name)
                                if child_descriptor is not None:
                                    directories.append((child_descriptor, (*components, entry.name), depth + 1))
                        except OSError:
                            continue
            except OSError:
                continue
            finally:
                _close_descriptor(directory_descriptor)
        return documents
    finally:
        while directories:
            descriptor, _, _ = directories.pop()
            _close_descriptor(descriptor)


def _directory_flags() -> int | None:
    if not hasattr(os, "O_NOFOLLOW") or not hasattr(os, "O_DIRECTORY"):
        return None
    return os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW


def _open_directory(path: Path) -> int | None:
    flags = _directory_flags()
    if flags is None:
        return None
    try:
        descriptor = os.open(path, flags)
        if stat.S_ISDIR(os.fstat(descriptor).st_mode):
            return descriptor
    except OSError:
        return None
    _close_descriptor(descriptor)
    return None


def _open_directory_at(parent_descriptor: int, name: str) -> int | None:
    flags = _directory_flags()
    if flags is None or not name or "/" in name or name in {".", ".."}:
        return None
    try:
        descriptor = os.open(name, flags, dir_fd=parent_descriptor)
        if stat.S_ISDIR(os.fstat(descriptor).st_mode):
            return descriptor
    except (OSError, TypeError):
        return None
    _close_descriptor(descriptor)
    return None


def _is_regular_file_at(parent_descriptor: int, name: str) -> bool:
    try:
        metadata = os.stat(name, dir_fd=parent_descriptor, follow_symlinks=False)
        return stat.S_ISREG(metadata.st_mode)
    except (OSError, TypeError):
        return False


def _close_descriptor(descriptor: int) -> None:
    try:
        os.close(descriptor)
    except OSError:
        pass


def _document_observation(root_descriptor: int, components: tuple[str, ...]) -> tuple[float, int, int] | None:
    if not hasattr(os, "O_NOFOLLOW") or not components:
        return None
    parent_descriptor = -1
    descriptor = -1
    try:
        parent_descriptor = os.dup(root_descriptor)
        for component in components[:-1]:
            next_descriptor = _open_directory_at(parent_descriptor, component)
            if next_descriptor is None:
                return None
            _close_descriptor(parent_descriptor)
            parent_descriptor = next_descriptor
        descriptor = os.open(components[-1], os.O_RDONLY | os.O_NOFOLLOW, dir_fd=parent_descriptor)
        metadata = os.fstat(descriptor)
        if not stat.S_ISREG(metadata.st_mode):
            return None
        mtime = metadata.st_mtime
        content = os.read(descriptor, _MAX_DOCUMENT_BYTES)
        lines = content.decode("utf-8").splitlines()
    except (OSError, TypeError, UnicodeError):
        return None
    finally:
        if descriptor >= 0:
            _close_descriptor(descriptor)
        if parent_descriptor >= 0:
            _close_descriptor(parent_descriptor)

    section = ""
    open_count = 0
    verification_count = 0
    for line in lines:
        heading = _HEADING_RE.match(line)
        if heading:
            section = heading.group(1).strip().casefold()
            continue
        if section in _OPEN_FOLLOW_HEADINGS and _LIST_ITEM_RE.match(line):
            open_count += 1
        elif section in _VERIFICATION_HEADINGS and _CHECKED_ITEM_RE.match(line):
            verification_count += 1
    return mtime, open_count, verification_count


def _git_worktree_dirty(root: Path) -> bool | None:
    try:
        result = subprocess.run(
            ["git", "--no-optional-locks", "-c", "core.fsmonitor=false", "-C", str(root), "status", "--porcelain"],
            check=False,
            capture_output=True,
            text=True,
            timeout=2,
        )
        return bool(result.stdout.strip()) if result.returncode == 0 else None
    except (OSError, subprocess.SubprocessError, ValueError):
        return None
