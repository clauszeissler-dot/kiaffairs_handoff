#!/usr/bin/env python3
"""Generate a local, privacy-preserving retrospective from Codex session logs.

The report intentionally keeps prompts and responses on the machine. It reads only
the local Codex rollout files, derives aggregate signals, and writes one standalone
HTML file with no network dependencies.
"""

from __future__ import annotations

import argparse
import collections
import datetime as dt
import html
import json
import math
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable

from claude_facets import load_claude_summary
from insight_state import InsightStore, Snapshot
from project_observer import observe_projects
from research import cache_sources, default_search as _default_research_search


CODEX_HOME = Path.home() / ".codex"
SESSIONS_ROOT = CODEX_HOME / "sessions"
DEFAULT_REPORT_DIR = CODEX_HOME / "insights" / "reports"
DEFAULT_PROFILE_PATH = CODEX_HOME / "insights" / "profile.json"
DEFAULT_STATE_ROOT = CODEX_HOME / "insights"
DEFAULT_CLAUDE_ROOT = Path.home() / ".claude" / "usage-data"
SYSTEM_PROMPT_MARKERS = (
    "<environment_context>",
    "<recommended_plugins>",
    "<permissions instructions>",
    "<developer_instructions>",
    "<apps_instructions>",
    "<skills_instructions>",
)
CORRECTION_PATTERNS = (
    r"\b(?:nochmal|erneut|wiederholen|anders|stattdessen)\b",
    r"\b(?:das|dies) (?:ist|war) (?:nicht|falsch|kaputt)\b",
    r"\b(?:funktioniert|klappt|passt) nicht\b",
    r"\b(?:fehlt|vergessen|übersehen)\b",
    r"\b(?:nein|stop)\b",
)
POSITIVE_PATTERNS = (
    r"\b(?:danke|perfekt|super|top|passt|genau|erledigt)\b",
    r"\b(?:sehr gut|gut so|weiter so)\b",
)
THEMES = {
    "Software & Produkt": ("app", "anwendung", "website", "frontend", "backend", "react", "api", "feature", "code", "software"),
    "Recherche & Strategie": ("recherche", "analys", "strategie", "konzept", "vergleich", "markt", "plan"),
    "Sicherheit & Datenschutz": ("datenschutz", "dsb", "avv", "nis2", "sicherheit", "audit", "vvt", "tom", "risiko"),
    "Inhalte & Medien": ("workshop", "präsentation", "buch", "podcast", "linkedin", "lyrics", "suno", "video"),
    "Automatisierung": ("automatis", "n8n", "workflow", "agent", "mcp", "hook", "integration"),
    "Betrieb & Fehlerbehebung": ("fehler", "debug", "test", "deploy", "docker", "build", "bug", "log"),
}


@dataclass(frozen=True)
class Recommendation:
    status: str
    title: str
    explanation: str
    value: str
    decision: str


@dataclass
class Session:
    path: Path
    started_at: dt.datetime | None = None
    cwd: str = ""
    user_prompts: list[str] = field(default_factory=list)
    tool_counts: collections.Counter[str] = field(default_factory=collections.Counter)
    corrections: int = 0
    positives: int = 0

    @property
    def prompt_words(self) -> int:
        return sum(len(prompt.split()) for prompt in self.user_prompts)


def parse_timestamp(value: str | None) -> dt.datetime | None:
    if not value:
        return None
    try:
        return dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def is_user_text(value: str) -> bool:
    stripped = value.lstrip()
    return bool(stripped) and not stripped.startswith(SYSTEM_PROMPT_MARKERS)


def extract_text(content: object) -> str:
    if not isinstance(content, list):
        return ""
    parts: list[str] = []
    for item in content:
        if isinstance(item, dict) and isinstance(item.get("text"), str):
            parts.append(item["text"])
    return "\n".join(parts)


def session_files(root: Path) -> Iterable[Path]:
    if not root.exists():
        return []
    return root.rglob("*.jsonl")


def parse_session(path: Path) -> Session:
    session = Session(path=path)
    try:
        with path.open("r", encoding="utf-8", errors="replace") as handle:
            for raw_line in handle:
                if "session_meta" in raw_line and session.started_at is None:
                    try:
                        entry = json.loads(raw_line)
                        payload = entry.get("payload", {})
                        session.started_at = parse_timestamp(payload.get("timestamp") or entry.get("timestamp"))
                        session.cwd = str(payload.get("cwd") or "")
                    except (json.JSONDecodeError, AttributeError):
                        pass
                    continue

                if '"role":"user"' in raw_line and '"input_text"' in raw_line:
                    try:
                        entry = json.loads(raw_line)
                        payload = entry.get("payload", {})
                        if payload.get("type") != "message" or payload.get("role") != "user":
                            continue
                        text = extract_text(payload.get("content"))
                    except (json.JSONDecodeError, AttributeError):
                        continue
                    if not is_user_text(text):
                        continue
                    normalized = " ".join(text.split())
                    session.user_prompts.append(normalized)
                    lowered = normalized.casefold()
                    session.corrections += sum(bool(re.search(pattern, lowered)) for pattern in CORRECTION_PATTERNS)
                    session.positives += sum(bool(re.search(pattern, lowered)) for pattern in POSITIVE_PATTERNS)
                    continue

                if '"type":"function_call"' in raw_line and '"name"' in raw_line:
                    try:
                        entry = json.loads(raw_line)
                        payload = entry.get("payload", {})
                        if payload.get("type") == "function_call" and isinstance(payload.get("name"), str):
                            session.tool_counts[payload["name"]] += 1
                    except (json.JSONDecodeError, AttributeError):
                        pass
    except OSError:
        return session

    if session.started_at is None:
        session.started_at = dt.datetime.fromtimestamp(path.stat().st_mtime, tz=dt.timezone.utc)
    return session


def project_label(cwd: str) -> str:
    if not cwd:
        return "Ohne Projektpfad"
    path = Path(cwd)
    if path.name:
        return path.name
    return cwd


def time_bucket(hour: int) -> str:
    if 5 <= hour < 12:
        return "Morgen"
    if 12 <= hour < 18:
        return "Tag"
    if 18 <= hour < 23:
        return "Abend"
    return "Nacht"


def pct(value: int | float, total: int | float) -> float:
    return 0 if not total else round((value / total) * 100, 1)


def safe(value: object) -> str:
    return html.escape(str(value), quote=True)


def bar_rows(values: collections.Counter[str], limit: int = 7) -> str:
    if not values:
        return '<p class="empty">Noch keine auswertbaren Daten.</p>'
    max_value = max(values.values())
    rows = []
    for label, value in values.most_common(limit):
        width = max(3, round((value / max_value) * 100))
        rows.append(
            f'<div class="bar-row"><div class="bar-label">{safe(label)}</div>'
            f'<div class="bar-track"><span style="width:{width}%"></span></div>'
            f'<strong>{value}</strong></div>'
        )
    return "".join(rows)


def finding_card(kind: str, title: str, evidence: str, action: str) -> str:
    return f'''<article class="finding {safe(kind)}">
      <div class="finding-kicker">{safe(kind)}</div>
      <h3>{safe(title)}</h3>
      <p class="evidence">{safe(evidence)}</p>
      <p class="action"><span>→</span>{safe(action)}</p>
    </article>'''


def recommendation_card(item: Recommendation) -> str:
    return f'''<article class="recommendation">
      <div class="recommendation-top"><span class="recommendation-status">{safe(item.status)}</span><span>Entscheidungshilfe</span></div>
      <h3>{safe(item.title)}</h3>
      <p>{safe(item.explanation)}</p>
      <dl><div><dt>Dein Nutzen</dt><dd>{safe(item.value)}</dd></div><div><dt>Meine Empfehlung</dt><dd>{safe(item.decision)}</dd></div></dl>
    </article>'''


def load_profile(path: Path) -> dict[str, str]:
    fallback = {
        "audience": "geschäftlich orientiert",
        "explanation_style": "klar und ohne unnötige Fachbegriffe",
        "decision_preference": "eine Empfehlung mit Nutzen, möglichem Nachteil und nächstem Schritt",
    }
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return fallback
    if not isinstance(value, dict):
        return fallback
    return {key: str(value.get(key) or default) for key, default in fallback.items()}


def build_recommendations(sessions: list[Session], totals: dict[str, int], profile: dict[str, str]) -> str:
    prompts = [prompt.casefold() for session in sessions for prompt in session.user_prompts]
    permission_hits = sum(bool(re.search(r"\b(?:freigab|permission|zugriff|all access|sandbox|approval)\b", prompt)) for prompt in prompts)
    automation_hits = sum(bool(re.search(r"\b(?:hook|skill|automatis|workflow|command|befehl|alias)\b", prompt)) for prompt in prompts)
    cards = [
        Recommendation(
            "Empfohlen",
            "Master-Modus für vertraute Projekte bewusst einsetzen",
            "Der Modus lässt Codex innerhalb deines Projekts arbeiten, ohne jede normale Aktion einzeln bestätigen zu lassen. Die Projekt-Sandbox bleibt dabei eingeschaltet.",
            "Weniger Unterbrechungen bei Routinearbeit. Du behältst die Grenze: außerhalb des Projektordners bleibt weiterhin Schutz aktiv.",
            "Für eigene oder bekannte Projekte mit „codex --master“ starten. Bei fremden Codebasen oder heiklen Daten weiterhin den normalen Modus verwenden.",
        ),
        Recommendation(
            "Aktiv",
            "Arbeitsende automatisch absichern",
            "Wenn du einen Arbeitstag beendest, wird ein kurzer Übergabezettel gespeichert. Morgen muss niemand erraten, was zuletzt entschieden oder geprüft wurde.",
            "Weniger Wiederholung und geringeres Risiko, dass ein wichtiger offener Punkt verloren geht.",
            "Einfach „Ende für heute“ schreiben. Der Handoff hält nur Arbeitsstand, Prüfung und nächsten Schritt fest, keinen Gesprächsmitschnitt.",
        ),
        Recommendation(
            "Geplant",
            "Alle zwei Wochen nach Vereinfachungen suchen",
            "Der Bericht wird automatisch erneuert. Er schaut auf wiederkehrende Arbeit, Rückfragen, Projekte und genutzte Werkzeuge – nie auf eine Leistungsbewertung.",
            "Du siehst, wo ein Standard, ein Hook oder ein kurzer Befehl künftig Zeit spart, statt dass du solche Chancen selbst suchen musst.",
            "Bei „/insights“ zuerst den vorhandenen Bericht ansehen. „/insights neu“ erzeugt bei Bedarf sofort eine frische Momentaufnahme.",
        ),
    ]
    if permission_hits:
        cards.append(Recommendation(
            "Beobachtet",
            "Freigaben sind ein wiederkehrendes Thema",
            f"In {permission_hits} Arbeitsaufträgen tauchen Begriffe rund um Zugriff, Freigabe oder Sandbox auf.",
            "Das ist ein Hinweis auf vermeidbare Unterbrechungen, nicht auf ein Sicherheitsproblem.",
            "Prüfe beim nächsten Bericht, ob der Master-Modus in vertrauten Projekten diese Rückfragen tatsächlich reduziert hat.",
        ))
    if automation_hits:
        cards.append(Recommendation(
            "Beobachtet",
            "Du arbeitest bereits an wiederholbaren Abläufen",
            f"{automation_hits} Arbeitsaufträge enthalten Hinweise auf Hooks, Skills, Befehle oder Automatisierung.",
            "Wiederholte Erklärungen und Handgriffe sind die besten Kandidaten für eine dauerhafte Vereinfachung.",
            "Nimm pro Bericht nur eine Wiederholung heraus und entscheide: fester Befehl, Hook oder bewusst manuell lassen.",
        ))
    intro = Recommendation(
        "Dein Arbeitsprofil",
        "Entscheidungen zuerst, Technik danach",
        f"Dieser Bericht erklärt Vorschläge {profile['explanation_style']}. Du musst keine technischen Details kennen, um eine gute Entscheidung zu treffen.",
        "Jede Empfehlung macht sichtbar: Was passiert, was bringt es dir und wo liegt die Grenze.",
        f"Deine gewünschte Art der Entscheidung: {profile['decision_preference']}.",
    )
    return recommendation_card(intro) + "".join(recommendation_card(card) for card in cards[:4])


def build_findings(sessions: list[Session], totals: dict[str, int], tools: collections.Counter[str]) -> tuple[str, str]:
    total_sessions = totals["sessions"]
    correction_rate = pct(totals["corrections"], max(1, totals["prompts"]))
    average_words = totals["words"] / max(1, totals["prompts"])
    findings: list[str] = []
    strengths: list[str] = []

    if totals["projects"] >= 5:
        strengths.append(finding_card("Stärke", "Breite Umsetzungskraft", f"{totals['projects']} unterschiedliche Projektbereiche wurden aktiv bearbeitet.", "Behalte die projektübergreifende Perspektive bei; sichere wiederkehrende Standards zentral als Skill oder Vorlage."))
    if totals["tools"] >= total_sessions:
        strengths.append(finding_card("Stärke", "Arbeit wird nicht nur besprochen", f"{totals['tools']} Tool-Aufrufe über {total_sessions} Sessions zeigen eine ausgeprägte Umsetzungsorientierung.", "Bei risikoreichen Schritten weiter auf kurze Verifikation direkt nach der Änderung bestehen."))
    if totals["positive"] > totals["corrections"]:
        strengths.append(finding_card("Stärke", "Klare Bestätigungsschleifen", f"{totals['positive']} positive Rückmeldesignale gegenüber {totals['corrections']} Korrektursignalen.", "Erfolgreiche Muster als Beispiele in die jeweiligen Projektanweisungen übernehmen."))
    if not strengths:
        strengths.append(finding_card("Stärke", "Kontinuierliche Arbeitsroutine", f"{total_sessions} dokumentierte Sessions bilden bereits eine belastbare Grundlage für Lernschleifen.", "Die nächste Analyse nach weiteren 10–15 Sessions erneut ausführen und Trends vergleichen."))

    if correction_rate >= 18:
        findings.append(finding_card("Hebel", "Viele Kurskorrekturen", f"{totals['corrections']} deutliche Korrektursignale in {totals['prompts']} Nutzer-Prompts ({correction_rate} %).", "Bei größeren Aufgaben zuerst Zielbild, Abnahmekriterien und Ausschlüsse in drei kurzen Punkten festhalten lassen."))
    elif correction_rate >= 8:
        findings.append(finding_card("Hebel", "Kurskorrekturen früh bündeln", f"{totals['corrections']} erkennbare Korrektursignale; die Zusammenarbeit ist steuerbar, aber nicht immer auf Anhieb präzise.", "Bei offenen Aufgaben einen kurzen Plan-Checkpoint vor der ersten Änderung nutzen."))

    if average_words > 180:
        findings.append(finding_card("Hebel", "Aufträge sind oft sehr umfangreich", f"Durchschnittlich {round(average_words)} Wörter pro Nutzer-Prompt.", "Große Briefings beibehalten, aber am Ende immer „Ergebnis“, „Nicht tun“ und „Prüfung“ als Mini-Checkliste ergänzen."))
    elif average_words < 35 and total_sessions >= 10:
        findings.append(finding_card("Hebel", "Mehr Startkontext spart Rückfragen", f"Durchschnittlich {round(average_words)} Wörter pro Nutzer-Prompt.", "Bei neuen Projekten Ziel, vorhandene Referenzen und gewünschtes Ergebnis direkt im ersten Auftrag bündeln."))

    validation_tools = sum(count for name, count in tools.items() if any(token in name.casefold() for token in ("test", "review", "check", "verify", "lint")))
    change_tools = sum(count for name, count in tools.items() if any(token in name.casefold() for token in ("patch", "write", "edit", "exec", "command")))
    if change_tools > 10 and validation_tools < max(3, change_tools * 0.08):
        findings.append(finding_card("Hebel", "Verifikation sichtbarer machen", f"{change_tools} umsetzungsnahe Tool-Aufrufe stehen nur {validation_tools} expliziten Prüfaufrufen gegenüber.", "Bei Änderungen standardmäßig einen passenden Test, Build, Review oder visuellen Check als Definition of Done verlangen."))

    if not findings:
        findings.append(finding_card("Hebel", "Nächster Reifegrad: Standards verdichten", "Die aggregierten Signale zeigen kein einzelnes dominantes Reibungsmuster.", "Wiederkehrende Formulierungen und erfolgreiche Vorgehensweisen als globale Skills, Hooks oder Projektregeln festschreiben."))

    return "".join(strengths[:3]), "".join(findings[:3])


def render_report(
    sessions: list[Session], generated_at: dt.datetime, scope: str, profile: dict[str, str],
    integration: dict[str, Any] | None = None,
) -> str:
    dated = [session for session in sessions if session.started_at]
    projects = collections.Counter(project_label(session.cwd) for session in dated)
    if integration is not None:
        # Project observation deliberately exposes only aggregate properties.  Do
        # not turn the project keys back into labels or paths in the report.
        projects = collections.Counter(
            {f"Projekt {index}": int(project.get("document_count", 0)) + 1
             for index, project in enumerate(integration.get("projects", []), start=1)}
        )
    tools = collections.Counter()
    themes = collections.Counter()
    daily = collections.Counter()
    time_of_day = collections.Counter()
    for session in dated:
        tools.update(session.tool_counts)
        daily[session.started_at.date().isoformat()] += 1
        time_of_day[time_bucket(session.started_at.astimezone().hour)] += 1
        text = " ".join(session.user_prompts).casefold()
        for theme, keywords in THEMES.items():
            if any(keyword in text for keyword in keywords):
                themes[theme] += 1

    totals = {
        "sessions": len(dated),
        "prompts": sum(len(session.user_prompts) for session in dated),
        "words": sum(session.prompt_words for session in dated),
        "corrections": sum(session.corrections for session in dated),
        "positive": sum(session.positives for session in dated),
        "projects": len(projects),
        "tools": sum(tools.values()),
        "days": len(daily),
    }
    strengths, levers = build_findings(dated, totals, tools)
    recommendations = build_recommendations(dated, totals, profile)
    span = "keine auswertbaren Sessions"
    if dated:
        start = min(session.started_at for session in dated).astimezone().strftime("%d.%m.%Y")
        end = max(session.started_at for session in dated).astimezone().strftime("%d.%m.%Y")
        span = f"{start} bis {end}"

    hours = [0] * 24
    for session in dated:
        hours[session.started_at.astimezone().hour] += 1
    max_hour = max(hours) if any(hours) else 1
    hour_bars = "".join(
        f'<div class="hour" title="{hour:02d}:00 · {value} Sessions"><span style="height:{max(3, round(value / max_hour * 100))}%"></span><small>{hour:02d}</small></div>'
        for hour, value in enumerate(hours)
    )
    trend_keys = sorted(daily)[-28:]
    trend_max = max((daily[key] for key in trend_keys), default=1)
    trend = "".join(
        f'<span title="{safe(key)} · {daily[key]} Sessions" style="height:{max(4, round(daily[key] / trend_max * 100))}%"></span>'
        for key in trend_keys
    ) or '<span style="height:4%"></span>'

    correction_rate = pct(totals["corrections"], max(1, totals["prompts"]))
    quality_label = "ruhig" if correction_rate < 8 else "lernend" if correction_rate < 18 else "intensiv"
    comparison = integration.get("comparison", {}) if integration else {}
    comparison_rows = "".join(
        f'<div class="bar-row"><div class="bar-label">{safe(item.get("label", "Momentaufnahme"))}</div>'
        f'<div class="bar-track"><span style="width:{max(3, min(100, int(item.get("sessions", 0)) * 12))}%"></span></div>'
        f'<strong>{safe(item.get("sessions", 0))}</strong></div>'
        for item in comparison.get("snapshots", [])
    ) or '<p class="empty">Noch keine Vergleichsmomente vorhanden.</p>'
    baseline_status = comparison.get("baseline_status", "missing")
    baseline_note = {
        "available": "Drei vollständige Vergleichsmomente sind verfügbar.",
        "restricted": "Vergleich eingeschränkt: ältere Momentaufnahmen enthalten nicht alle Kennzahlen.",
        "nicht belastbar": "nicht belastbar: Es gibt noch keine vollständige Vergleichsgrundlage.",
    }.get(baseline_status, "Vergleichsgrundlage unbekannt.")
    comparison_labels = {
        "sessions": "Sessions", "prompts": "Prompts", "tools": "Tool-Aufrufe", "projects": "Projektbereiche",
        "claude_friction": "Claude-Reibungssignale", "project_signals": "Projekt-Signale",
    }

    def comparison_total(value: object) -> int:
        if isinstance(value, dict):
            return sum(item for item in value.values() if isinstance(item, int) and not isinstance(item, bool))
        return value if isinstance(value, int) and not isinstance(value, bool) else 0

    comparison_metric_rows = "".join(
        f'<div class="bar-row"><div class="bar-label">{safe(label)}</div>'
        f'<div class="bar-track"><span style="width:{max(3, min(100, comparison_total(comparison.get("current_metrics", {}).get(key)) * 12))}%"></span></div>'
        f'<strong>{comparison_total(comparison.get("current_metrics", {}).get(key))}</strong></div>'
        for key, label in comparison_labels.items()
    )
    research = integration.get("research", []) if integration else []
    research_rows = "".join(
        f'<li><a href="{safe(source.get("url", ""))}" rel="noreferrer">{safe(source.get("title", "Quelle"))}</a> <span class="legend">{safe(source.get("topic", ""))}</span></li>'
        for source in research if source.get("url") and source.get("title")
    ) or '<p class="empty">Keine neuen öffentlichen Quellen erforderlich.</p>'
    return f'''<!doctype html>
<html lang="de">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Lokaler Codex Insights Bericht">
  <title>Codex Insights · {generated_at.strftime('%d.%m.%Y')}</title>
  <style>
    :root {{ --bg:#141414; --bg2:#1a1a1a; --card:#212121; --card2:#1c1c1c; --orange:hsl(22 97% 60%); --cyan:hsl(187 100% 50%); --green:hsl(142 65% 48%); --red:#ef4444; --fg:#f0f0f0; --muted:#a6a6a6; --border:rgba(255,255,255,.09); --radius:18px; }}
    * {{ box-sizing:border-box; }} html {{ scroll-behavior:smooth; }} body {{ margin:0; background:radial-gradient(circle at 12% 0%,rgba(0,217,255,.11),transparent 29rem),radial-gradient(circle at 87% 16%,rgba(255,116,58,.13),transparent 30rem),var(--bg); color:var(--fg); font:16px/1.55 Inter, ui-sans-serif, system-ui, sans-serif; }}
    body:before {{ content:""; position:fixed; inset:0; pointer-events:none; opacity:.35; background-image:linear-gradient(rgba(255,255,255,.018) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.018) 1px,transparent 1px); background-size:32px 32px; mask-image:linear-gradient(to bottom,black,transparent 92%); }}
    .topline {{ height:4px; position:sticky; top:0; z-index:2; background:linear-gradient(90deg,var(--cyan),var(--orange)); }} main {{ width:min(1180px,calc(100% - 40px)); margin:auto; padding:48px 0 74px; }}
    .eyebrow,.finding-kicker {{ color:var(--cyan); font:700 .72rem/1.2 ui-monospace,SFMono-Regular,Menlo,monospace; letter-spacing:.12em; text-transform:uppercase; }}
    .hero {{ min-height:340px; display:grid; grid-template-columns:1.3fr .7fr; gap:40px; align-items:end; padding:38px 0 52px; border-bottom:1px solid var(--border); }} h1,h2,h3 {{ font-family:"Space Grotesk",Inter,ui-sans-serif,sans-serif; line-height:1.04; margin:0; }} h1 {{ font-size:clamp(3.1rem,8vw,7.4rem); letter-spacing:-.065em; max-width:850px; }} h1 em {{ color:var(--orange); font-style:normal; }} .hero p {{ color:var(--muted); max-width:62ch; margin:21px 0 0; }}
    .scope {{ align-self:center; padding:22px; border:1px solid var(--border); border-radius:var(--radius); background:rgba(33,33,33,.78); backdrop-filter:blur(12px); }} .scope strong {{ display:block; font-size:1.7rem; margin:7px 0; }} .scope small {{ color:var(--muted); }}
    .section {{ padding:55px 0 0; }} .section-head {{ display:flex; justify-content:space-between; gap:18px; align-items:end; margin-bottom:22px; }} .section-head p {{ color:var(--muted); margin:0; max-width:52ch; }} h2 {{ font-size:clamp(1.8rem,3vw,3rem); letter-spacing:-.045em; }}
    .metrics {{ display:grid; grid-template-columns:repeat(4,1fr); gap:13px; }} .metric,.panel,.finding {{ border:1px solid var(--border); border-radius:var(--radius); background:linear-gradient(145deg,rgba(39,39,39,.96),rgba(25,25,25,.96)); }} .metric {{ padding:20px; min-height:145px; }} .metric b {{ display:block; font:700 clamp(2rem,4vw,3.7rem)/1 "Space Grotesk",sans-serif; letter-spacing:-.07em; color:var(--fg); margin-top:11px; }} .metric span {{ color:var(--muted); font-size:.86rem; }} .metric.cyan b {{ color:var(--cyan); }} .metric.orange b {{ color:var(--orange); }}
    .grid-2 {{ display:grid; grid-template-columns:1fr 1fr; gap:16px; }} .panel {{ padding:25px; }} .panel h3 {{ font-size:1.25rem; letter-spacing:-.025em; margin-bottom:20px; }} .bar-row {{ display:grid; grid-template-columns:minmax(105px,1.4fr) 3fr 34px; gap:12px; align-items:center; margin:11px 0; font-size:.87rem; }} .bar-label {{ color:#d8d8d8; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }} .bar-track {{ height:8px; overflow:hidden; background:#121212; border-radius:20px; }} .bar-track span {{ display:block; height:100%; border-radius:20px; background:linear-gradient(90deg,var(--cyan),var(--orange)); }} .bar-row strong {{ text-align:right; font:700 .77rem ui-monospace,monospace; color:var(--muted); }}
    .hours {{ height:180px; display:flex; align-items:end; gap:4px; padding-top:16px; }} .hour {{ flex:1; height:100%; display:flex; flex-direction:column; justify-content:end; align-items:center; gap:6px; }} .hour span {{ width:100%; min-height:3px; border-radius:5px 5px 0 0; background:linear-gradient(to top,var(--cyan),var(--orange)); opacity:.86; }} .hour small {{ color:var(--muted); font-size:.58rem; transform:rotate(-55deg); margin-top:4px; }}
    .trend {{ height:110px; display:flex; align-items:end; gap:4px; padding:12px 0 5px; border-bottom:1px solid var(--border); }} .trend span {{ flex:1; min-width:3px; border-radius:3px 3px 0 0; background:var(--orange); opacity:.82; }} .legend {{ color:var(--muted); font-size:.8rem; margin:12px 0 0; }}
    .findings {{ display:grid; grid-template-columns:repeat(3,1fr); gap:14px; }} .finding {{ padding:22px; min-height:245px; display:flex; flex-direction:column; }} .finding.Hebel .finding-kicker {{ color:var(--orange); }} .finding h3 {{ font-size:1.33rem; letter-spacing:-.035em; margin:13px 0 10px; }} .finding .evidence {{ color:var(--muted); margin:0; }} .finding .action {{ margin:auto 0 0; padding-top:18px; font-weight:650; }} .finding .action span {{ color:var(--cyan); margin-right:8px; }}
    .recommendations {{ display:grid; grid-template-columns:repeat(2,1fr); gap:14px; }} .recommendation {{ padding:23px; border:1px solid var(--border); border-radius:var(--radius); background:linear-gradient(140deg,rgba(0,217,255,.075),rgba(31,31,31,.98) 32%,rgba(255,116,58,.05)); }} .recommendation-top {{ display:flex; align-items:center; justify-content:space-between; gap:12px; color:var(--muted); font:700 .68rem/1 ui-monospace,SFMono-Regular,Menlo,monospace; letter-spacing:.09em; text-transform:uppercase; }} .recommendation-status {{ padding:6px 8px; border-radius:999px; color:#061719; background:var(--cyan); }} .recommendation h3 {{ margin:16px 0 10px; font-size:1.45rem; letter-spacing:-.035em; }} .recommendation p {{ color:#d7d7d7; margin:0; }} .recommendation dl {{ display:grid; grid-template-columns:1fr 1fr; gap:12px; margin:19px 0 0; }} .recommendation dl div {{ padding-top:12px; border-top:1px solid var(--border); }} .recommendation dt {{ color:var(--orange); font:700 .68rem/1.2 ui-monospace,monospace; letter-spacing:.08em; text-transform:uppercase; }} .recommendation dd {{ margin:7px 0 0; color:var(--muted); font-size:.88rem; }}
    .method {{ margin-top:16px; padding:17px 20px; border-left:2px solid var(--cyan); background:rgba(0,217,255,.055); color:var(--muted); font-size:.88rem; }} .empty {{ color:var(--muted); }} footer {{ margin-top:62px; display:flex; justify-content:space-between; gap:20px; border-top:1px solid var(--border); padding-top:18px; color:var(--muted); font-size:.78rem; }}
    @media (max-width:800px) {{ main {{ width:min(100% - 28px,1180px); }} .hero,.grid-2,.recommendations {{ grid-template-columns:1fr; }} .metrics {{ grid-template-columns:repeat(2,1fr); }} .findings {{ grid-template-columns:1fr; }} .recommendation dl {{ grid-template-columns:1fr; }} .hero {{ gap:20px; }} }} @media print {{ body {{ background:#fff; color:#111; }} body:before,.topline {{ display:none; }} main {{ width:100%; padding:0; }} .metric,.panel,.finding,.scope,.recommendation {{ color:#111; background:#fff; border-color:#ccc; box-shadow:none; }} .metric b,.bar-label,.finding .evidence,.recommendation p,.recommendation dd,.legend,.hero p,footer,.scope small {{ color:#444; }} .section {{ break-inside:avoid; }} }}
  </style>
</head>
<body>
<div class="topline"></div>
<main>
  <header class="hero">
    <div><div class="eyebrow">Lokaler Arbeitsrückblick · Codex</div><h1>Weniger Reibung.<br><em>Mehr Wirkung.</em></h1><p>Ein datensparsamer Rückblick auf deine Codex-Arbeit: Muster, Stärken und die nächsten sinnvollen Verbesserungen. Analyse, Prompts und Projektdaten bleiben lokal. Nur bei einer Aktualisierung können allgemeine, freigegebene Rechercheanfragen öffentliche Quellen erreichen.</p></div>
    <aside class="scope"><div class="eyebrow">Auswertung</div><strong>{safe(scope)}</strong><small>{safe(span)}<br>Erstellt am {generated_at.strftime('%d.%m.%Y · %H:%M')}</small></aside>
  </header>
  <section class="section"><div class="section-head"><div><div class="eyebrow">Arbeitsbild</div><h2>Deine Spuren im System</h2></div><p>Die Zahlen sind keine Leistungsbewertung. Sie machen sichtbar, wo deine Zusammenarbeit bereits trägt und wo ein kleiner Standard viel Wirkung entfaltet.</p></div>
    <div class="metrics"><article class="metric cyan"><span>Sessions</span><b>{totals['sessions']}</b><span>{totals['days']} aktive Kalendertage</span></article><article class="metric"><span>Nutzer-Prompts</span><b>{totals['prompts']}</b><span>{round(totals['words'] / max(1, totals['prompts']))} Wörter im Schnitt</span></article><article class="metric orange"><span>Projektbereiche</span><b>{totals['projects']}</b><span>Arbeitskontexte erkannt</span></article><article class="metric"><span>Tool-Aufrufe</span><b>{totals['tools']}</b><span>Umsetzungsorientierte Arbeit</span></article></div>
  </section>
  <section class="section grid-2"><article class="panel"><div class="eyebrow">Fokus</div><h3>Woran du gearbeitet hast</h3>{bar_rows(themes)}</article><article class="panel"><div class="eyebrow">Projekte</div><h3>Die aktivsten Arbeitsräume</h3>{bar_rows(projects)}</article></section>
  <section class="section grid-2"><article class="panel"><div class="eyebrow">Rhythmus</div><h3>Sessions nach Uhrzeit</h3><div class="hours">{hour_bars}</div><p class="legend">Lokale Uhrzeit · Höhe = Sessions je Stunde</p></article><article class="panel"><div class="eyebrow">Takt</div><h3>Letzte 28 aktive Tage</h3><div class="trend">{trend}</div><p class="legend">{len(trend_keys)} Tage mit Aktivität · Verlauf statt Tageswertung</p><div class="bar-row" style="margin-top:22px"><div class="bar-label">Kurskorrekturen</div><div class="bar-track"><span style="width:{max(3, min(100, correction_rate * 3))}%"></span></div><strong>{correction_rate}%</strong></div><p class="legend">Zusammenarbeit: <b style="color:var(--fg)">{quality_label}</b> · Signale werden nur heuristisch erkannt.</p></article></section>
  <section class="section grid-2"><article class="panel"><div class="eyebrow">Vergleich</div><h3>Vorher</h3>{comparison_rows}<p class="legend">{safe(baseline_note)}</p></article><article class="panel"><div class="eyebrow">Entwicklung</div><h3>Nachher</h3><p class="legend">Die aktuelle Momentaufnahme wird erst nach dem erfolgreichen Schreiben dieses Berichts als gesehen markiert.</p>{comparison_metric_rows}</article></section>
  <section class="section"><div class="section-head"><div><div class="eyebrow">Öffentliche Quellen</div><h2>Recherche</h2></div><p>Nur allgemeine, freigegebene Suchthemen aus aggregierten Reibungssignalen können öffentliche Quellen erreichen. Keine Prompts oder Projektdaten werden als Suchanfrage verwendet.</p></div><article class="panel"><ul>{research_rows}</ul></article></section>
  <section class="section"><div class="section-head"><div><div class="eyebrow">Produktivitäts-Coach</div><h2>Was du konkret vereinfachen kannst</h2></div><p>Kein Technik-Test: Jede Karte übersetzt Beobachtungen in eine verständliche Entscheidung mit klarer Grenze.</p></div><div class="recommendations">{recommendations}</div></section>
  <section class="section"><div class="section-head"><div><div class="eyebrow">Was trägt</div><h2>Stärken, die du ausbauen kannst</h2></div></div><div class="findings">{strengths}</div></section>
  <section class="section"><div class="section-head"><div><div class="eyebrow">Nächster Hebel</div><h2>Weniger Umwege im nächsten Durchlauf</h2></div></div><div class="findings">{levers}</div><p class="method">Methodik: Die Analyse läuft lokal und sendet keine Prompts oder Projektdaten. Der Bericht speichert keine Gesprächskopie und zeigt keine Prompt-Inhalte. Ausschließlich allgemeine, freigegebene Rechercheanfragen können öffentliche Quellen erreichen; ihre Aktualisierung startest du mit /insights neu. Die Deutung ist bewusst vorsichtig: Sie ist ein Gesprächsstart, kein Urteil.</p></section>
  <footer><span>CODEX INSIGHTS · lokal generiert</span><span>{safe(scope)} · {totals['sessions']} Sessions</span></footer>
</main>
</body></html>'''


def _report_metrics(sessions: list[Session], projects: list[dict[str, object]], claude: dict[str, Any]) -> dict[str, Any]:
    dated = [session for session in sessions if session.started_at]
    return {
        "sessions": len(dated),
        "prompts": sum(len(session.user_prompts) for session in dated),
        "tools": sum(sum(session.tool_counts.values()) for session in dated),
        "projects": len(projects),
        "claude_friction": dict(claude.get("friction_counts", {})),
        "project_signals": {
            "documents": sum(int(project.get("document_count", 0)) for project in projects),
            "open_follow_steps": sum(int(project.get("open_follow_steps", 0)) for project in projects),
            "verification_markers": sum(int(project.get("verification_markers", 0)) for project in projects),
            "dirty_worktrees": sum(project.get("git_worktree_dirty") is True for project in projects),
        },
    }


def _seed_state_if_absent(store: InsightStore, *, persist: bool = True) -> bool:
    """Create the legacy-compatible state file once, never repairing it in place."""
    path = store.root / "state.json"
    absent = not path.exists()
    if absent and persist:
        store._atomic_write(path, store.state())
        if not any(snapshot.report_id == "legacy-20260831" for snapshot in store.latest_snapshots(10**9)):
            store.save_snapshot(Snapshot(
                "legacy-20260831", dt.datetime(2026, 8, 31, tzinfo=dt.timezone.utc), "legacy", {}, [], {}, [], []
            ))
    return absent


def _record_scheduled_at(store: InsightStore, now: dt.datetime) -> None:
    """Update a valid state document without overwriting malformed legacy state."""
    path = store.root / "state.json"
    value, valid = store._read_json(path)
    if valid and isinstance(value, dict):
        state = store.state()
        state["last_scheduled_at"] = now.astimezone(dt.timezone.utc).isoformat()
        store._atomic_write(path, state)


_COMPARISON_METRICS = ("sessions", "prompts", "tools", "projects", "claude_friction", "project_signals")


def _comparison(previous: list[Snapshot], current_metrics: dict[str, Any]) -> dict[str, Any]:
    items = []
    restricted = len(previous) < 3
    for index, snapshot in enumerate(previous, start=1):
        metrics = {key: snapshot.metrics.get(key) for key in _COMPARISON_METRICS if key in snapshot.metrics}
        restricted = restricted or len(metrics) != len(_COMPARISON_METRICS)
        items.append({
            "report_id": snapshot.report_id,
            "label": f"Vorher {index}",
            "generated_at": snapshot.generated_at.isoformat(),
            "metrics": metrics,
            "sessions": metrics.get("sessions", 0),
        })
    return {
        "baseline_status": "nicht belastbar" if not items or not any(item["metrics"] for item in items) else "restricted" if restricted else "available",
        "snapshots": items,
        "current_metrics": {key: current_metrics.get(key, 0) for key in _COMPARISON_METRICS},
    }


def _scheduled_gap(state: dict[str, Any], now: dt.datetime) -> dict[str, Any] | None:
    last_scheduled = state.get("last_scheduled_at")
    previous = parse_timestamp(last_scheduled) if isinstance(last_scheduled, str) else None
    if previous is None:
        return None
    elapsed = now.astimezone(dt.timezone.utc) - previous.astimezone(dt.timezone.utc)
    if elapsed <= dt.timedelta(days=14):
        return None
    return {
        "kind": "scheduled_run_late",
        "from": previous.date().isoformat(),
        "to": now.astimezone(dt.timezone.utc).date().isoformat(),
        "late_by_days": math.ceil((elapsed - dt.timedelta(days=14)).total_seconds() / dt.timedelta(days=1).total_seconds()),
    }


def _merge_todos(store: InsightStore, additions: list[dict[str, str]], *, persist: bool = True) -> list[dict[str, Any]]:
    path = store.root / "todos.json"
    existing, valid = store._read_json(path)
    if not additions:
        return existing if valid and isinstance(existing, list) else []
    if valid and (existing is None or isinstance(existing, list)):
        merged = list(existing or [])
        for todo in additions:
            if todo not in merged:
                merged.append(todo)
        if persist:
            store._atomic_write(path, merged)
        return merged
    if persist:
        store._atomic_write(store.root / "todos.recovered.json", {"todos": additions})
    return additions


def _cached_research(path: Path) -> list[dict[str, str]]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, TypeError, ValueError):
        return []
    return value if isinstance(value, list) else []


def _validate_artifacts(html_path: Path, store: InsightStore, report_id: str) -> None:
    if not html_path.is_file() or not html_path.read_text(encoding="utf-8"):
        raise RuntimeError("report HTML could not be validated")
    if not any(snapshot.report_id == report_id for snapshot in store.latest_snapshots(10**9)):
        raise RuntimeError("report snapshot could not be validated")


def _write_html(path: Path, document: str) -> None:
    path.write_text(document, encoding="utf-8")


def _file_bytes(path: Path) -> bytes | None:
    try:
        return path.read_bytes()
    except FileNotFoundError:
        return None


def _restore_file(path: Path, content: bytes | None) -> None:
    if content is None:
        path.unlink(missing_ok=True)
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content)


def run_report(
    mode: str, output_dir: Path, state_root: Path, sessions_root: Path, claude_root: Path,
    now: dt.datetime, search: Callable[[str], Iterable[dict[str, Any]]], profile_path: Path,
    *, force_research_refresh: bool = False,
) -> dict[str, Any]:
    """Generate an integrated report without making a network request itself."""
    if mode not in {"scheduled", "active"}:
        raise ValueError("mode must be scheduled or active")
    if now.tzinfo is None or now.utcoffset() is None:
        raise ValueError("now must be timezone-aware")

    if force_research_refresh and mode != "active":
        raise ValueError("force_research_refresh is available only in active mode")
    store = InsightStore(state_root)
    research_path = Path(state_root) / "research.json"
    research_stage = Path(state_root) / ".research.active.stage.json"
    stamp = now.astimezone().strftime("%Y%m%d_%H%M%S")
    report_id = f"codex_insights_{stamp}_{mode}"
    output_dir = Path(output_dir)
    html_path = output_dir / f"{report_id}.html"
    rollback = {
        path: _file_bytes(path)
        for path in (
            html_path, store.root / "state.json", store.root / "todos.json",
            store.root / "todos.recovered.json", research_path,
            store.snapshots_dir / f"{report_id}.json", store.snapshots_dir / "legacy-20260831.json",
        )
    }
    try:
        state_was_absent = _seed_state_if_absent(store, persist=mode != "active")
        parsed = [parse_session(path) for path in session_files(sessions_root)]
        parsed = [session for session in parsed if session.user_prompts and session.started_at]
        parsed.sort(key=lambda item: item.started_at or now)
        claude = load_claude_summary(claude_root)
        metadata = list(Path(claude_root).rglob("*.json")) if Path(claude_root).exists() else []
        projects = observe_projects((session.cwd for session in parsed), metadata)
        metrics = _report_metrics(parsed, projects, claude)
        previous = store.latest_snapshots(3)
        if state_was_absent:
            previous = [Snapshot("legacy-20260831", dt.datetime(2026, 8, 31, tzinfo=dt.timezone.utc), "legacy", {}, [], {}, [], [])] + previous
            previous = sorted(previous, key=lambda snapshot: snapshot.generated_at)[-3:]
        gap = _scheduled_gap(store.state(), now) if mode == "scheduled" else None
        if mode == "active":
            if force_research_refresh:
                research_result = cache_sources(research_stage, claude.get("friction_counts", {}), search, now=now)
            else:
                research_result = {"sources": _cached_research(research_path), "todos": []}
        else:
            research_result = cache_sources(research_path, claude.get("friction_counts", {}), search, now=now)
        todo_additions = list(research_result["todos"])
        if gap:
            todo_additions.append({"status": "open", "message": "Vergleichslücke im nächsten Bericht erneut prüfen."})
        todos = _merge_todos(store, todo_additions, persist=mode != "active")
        comparison = _comparison(previous, metrics) if mode == "active" else {"snapshots": []}
        snapshot = Snapshot(report_id, now, mode, metrics, [], comparison, [gap] if gap else [], [source["url"] for source in research_result["sources"]])
        output_dir.mkdir(parents=True, exist_ok=True)
        _write_html(
            html_path, render_report(parsed, now.astimezone(), "Aktive Auswertung" if mode == "active" else "Geplante Momentaufnahme", load_profile(profile_path), {
                "projects": projects, "comparison": comparison, "research": research_result["sources"],
            })
        )
        if mode == "active" and state_was_absent:
            _seed_state_if_absent(store)
        store.save_snapshot(snapshot)
        if mode == "scheduled":
            _record_scheduled_at(store, now)
        else:
            _validate_artifacts(html_path, store, report_id)
            if not store.mark_viewed(report_id, now):
                raise RuntimeError("report snapshot could not be marked as viewed")
            if force_research_refresh and research_stage.exists():
                store._atomic_write(research_path, research_result["sources"])
            _merge_todos(store, todo_additions)
        return {"html_path": html_path, "snapshot": snapshot, "comparison": comparison, "todos": todos}
    except Exception:
        for path, content in rollback.items():
            _restore_file(path, content)
        raise
    finally:
        research_stage.unlink(missing_ok=True)


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate a local Codex Insights HTML report.")
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--days", type=int, default=90, help="Analyse sessions from the last N days (default: 90).")
    group.add_argument("--all", action="store_true", help="Analyse all local sessions.")
    group.add_argument("--latest", action="store_true", help="Print the newest existing report without analysing sessions.")
    group.add_argument("--scheduled", action="store_true", help="Create a scheduled snapshot without marking it viewed.")
    group.add_argument("--active", action="store_true", help="Create and mark an actively viewed report.")
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_REPORT_DIR, help="Directory for the generated HTML report.")
    parser.add_argument("--profile", type=Path, default=DEFAULT_PROFILE_PATH, help="Optional local preferences profile for the report language.")
    parser.add_argument("--state-root", type=Path, default=DEFAULT_STATE_ROOT, help="Local snapshot and state directory.")
    parser.add_argument("--sessions-root", type=Path, default=SESSIONS_ROOT, help="Local Codex sessions directory.")
    parser.add_argument("--claude-root", type=Path, default=DEFAULT_CLAUDE_ROOT, help="Local Claude summary directory.")
    parser.add_argument("--force-research-refresh", action="store_true", help="Refresh public research sources for an active report.")
    args = parser.parse_args()

    if args.force_research_refresh and not args.active:
        parser.error("--force-research-refresh is available only with --active")

    if args.latest:
        reports = sorted(
            args.output_dir.glob("codex_insights_*.html"),
            key=lambda report: report.stat().st_mtime,
            reverse=True,
        )
        if not reports:
            print("Kein vorhandener Codex-Insights-Bericht.", file=sys.stderr)
            return 2
        print(reports[0])
        return 0

    now = dt.datetime.now(tz=dt.timezone.utc)
    if args.scheduled or args.active:
        result = run_report(
            "active" if args.active else "scheduled", args.output_dir, args.state_root,
            args.sessions_root, args.claude_root, now, _default_research_search, args.profile,
            force_research_refresh=args.force_research_refresh,
        )
        print(result["html_path"])
        print(f"sessions={result['snapshot'].metrics['sessions']} mode={result['snapshot'].kind}")
        return 0

    cutoff = None if args.all else now - dt.timedelta(days=max(1, args.days))
    parsed: list[Session] = []
    for file_path in session_files(args.sessions_root):
        session = parse_session(file_path)
        if not session.user_prompts or session.started_at is None:
            continue
        if cutoff and session.started_at < cutoff:
            continue
        parsed.append(session)

    parsed.sort(key=lambda item: item.started_at or now)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    stamp = now.astimezone().strftime("%Y%m%d_%H%M%S")
    scope = "Alle lokalen Sessions" if args.all else f"Letzte {args.days} Tage"
    output = args.output_dir / f"codex_insights_{stamp}.html"
    output.write_text(render_report(parsed, now.astimezone(), scope, load_profile(args.profile)), encoding="utf-8")
    print(output)
    print(f"sessions={len(parsed)} scope={scope}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
