"""Small, local persistence layer for generated insight reports."""

from __future__ import annotations

import json
import os
import tempfile
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
import math
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class Snapshot:
    report_id: str
    generated_at: datetime
    kind: str
    metrics: dict[str, Any]
    recommendations: list[Any]
    comparison: dict[str, Any]
    gaps: list[Any]
    research_ids: list[str]

    def to_dict(self) -> dict[str, Any]:
        _utc_timestamp(self.generated_at)
        value = asdict(self)
        value["generated_at"] = _utc_timestamp(self.generated_at).isoformat()
        return value

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "Snapshot":
        fields = {"report_id", "generated_at", "kind", "metrics", "recommendations", "comparison", "gaps", "research_ids"}
        if not isinstance(value, dict) or not fields.issubset(value):
            raise ValueError("invalid snapshot schema")
        if not isinstance(value["report_id"], str) or not isinstance(value["kind"], str):
            raise ValueError("invalid snapshot strings")
        for field in ("metrics", "comparison"):
            if not isinstance(value[field], dict):
                raise ValueError("invalid snapshot mapping")
        for field in ("recommendations", "gaps", "research_ids"):
            if not isinstance(value[field], list):
                raise ValueError("invalid snapshot list")
        parsed = dict(value)
        parsed["generated_at"] = _utc_timestamp(datetime.fromisoformat(value["generated_at"]))
        return cls(**parsed)


def _utc_timestamp(value: datetime) -> datetime:
    if value.tzinfo is None or value.utcoffset() is None:
        raise ValueError("timestamps must be timezone-aware")
    return value.astimezone(timezone.utc)


class InsightStore:
    def __init__(self, root: str | Path):
        self.root = Path(root)
        self.snapshots_dir = self.root / "snapshots"
        self.snapshots_dir.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _read_json(path: Path) -> tuple[Any, bool]:
        if not path.exists():
            return None, True
        try:
            return json.loads(path.read_text(encoding="utf-8")), True
        except (OSError, ValueError, TypeError):
            return None, False

    @staticmethod
    def _atomic_write(path: Path, value: Any) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        handle = tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=path.parent, prefix=f".{path.name}.", suffix=".tmp", delete=False
        )
        temporary = Path(handle.name)
        try:
            with handle:
                json.dump(value, handle, ensure_ascii=False, indent=2)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, path)
        finally:
            temporary.unlink(missing_ok=True)

    def save_snapshot(self, snapshot: Snapshot) -> None:
        if not isinstance(snapshot.report_id, str) or not snapshot.report_id or snapshot.report_id == ".." or "/" in snapshot.report_id or "\\" in snapshot.report_id:
            raise ValueError("unsafe report ID")
        serialized = snapshot.to_dict()
        Snapshot.from_dict(serialized)
        self._atomic_write(self.snapshots_dir / f"{snapshot.report_id}.json", serialized)

    def latest_snapshots(self, limit: int = 3) -> list[Snapshot]:
        snapshots: list[Snapshot] = []
        for path in self.snapshots_dir.glob("*.json"):
            data, valid_json = self._read_json(path)
            if not valid_json or not isinstance(data, dict):
                continue
            try:
                snapshots.append(Snapshot.from_dict(data))
            except (KeyError, TypeError, ValueError):
                continue
        snapshots.sort(key=lambda item: item.generated_at)
        return snapshots[-limit:] if limit > 0 else []

    def state(self) -> dict[str, Any]:
        data, valid = self._read_json(self.root / "state.json")
        defaults = {"last_viewed_report_id": None, "last_viewed_on": None, "last_scheduled_at": None}
        if valid and isinstance(data, dict):
            defaults.update({key: data.get(key) for key in defaults})
        return defaults

    def record_schedule_gap(self, previous: Snapshot | None, now: datetime) -> dict[str, Any] | None:
        if previous is None:
            return None
        now = _utc_timestamp(now)
        previous_at = _utc_timestamp(previous.generated_at)
        elapsed = now - previous_at
        if elapsed <= timedelta(days=14):
            return None
        late_by_days = math.ceil((elapsed - timedelta(days=14)).total_seconds() / timedelta(days=1).total_seconds())
        gap = {
            "kind": "scheduled_run_late",
            "from": previous_at.date().isoformat(),
            "to": now.date().isoformat(),
            "late_by_days": late_by_days,
        }
        todos_path = self.root / "todos.json"
        todos, valid = self._read_json(todos_path)
        todo = {"status": "open", "message": "Vergleichslücke im nächsten Bericht erneut prüfen."}
        if valid and todos is None:
            todos = []
        if valid and isinstance(todos, list):
            todos.append(todo)
            self._atomic_write(todos_path, todos)
        else:
            self._atomic_write(self.root / "todos.recovered.json", {"gap": gap, "todos": [todo]})
        return gap

    def mark_viewed(self, report_id: str, viewed_on: datetime) -> bool:
        if not any(item.report_id == report_id for item in self._all_snapshots()):
            return False
        path = self.root / "state.json"
        data, valid = self._read_json(path)
        if not valid:
            return False
        state = self.state()
        state["last_viewed_report_id"] = report_id
        state["last_viewed_on"] = _utc_timestamp(viewed_on).isoformat()
        self._atomic_write(path, state)
        return True

    def _all_snapshots(self) -> list[Snapshot]:
        return self.latest_snapshots(limit=10**9)
