"""Read-only aggregation of the allowlisted Claude facet fields."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


_COUNTER_FIELDS = ("goal_categories", "user_satisfaction_counts", "friction_counts")
_LABEL_FIELDS = ("outcome", "session_type", "claude_helpfulness")


def load_claude_summary(root: Path) -> dict[str, Any]:
    """Aggregate safe summary fields from JSON files directly under ``facets``."""
    summary: dict[str, Any] = {field: {} for field in (*_COUNTER_FIELDS, *_LABEL_FIELDS)}
    facets_dir = Path(root) / "facets"

    try:
        facet_paths = sorted(facets_dir.glob("*.json"))
        for path in facet_paths:
            try:
                facet = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, TypeError, ValueError):
                continue
            if not isinstance(facet, dict):
                continue

            for field in _COUNTER_FIELDS:
                counters = facet.get(field)
                if not isinstance(counters, dict):
                    continue
                for label, count in counters.items():
                    if isinstance(label, str) and label and isinstance(count, int) and not isinstance(count, bool) and count >= 0:
                        summary[field][label] = summary[field].get(label, 0) + count

            for field in _LABEL_FIELDS:
                label = facet.get(field)
                if isinstance(label, str) and label:
                    summary[field][label] = summary[field].get(label, 0) + 1
    except OSError:
        pass

    return {field: dict(sorted(values.items())) for field, values in summary.items()}
