"""Privacy-preserving helpers for optional research-source lookups."""

from __future__ import annotations

from datetime import datetime, timezone
import os
from http.client import HTTPSConnection
import ipaddress
import json
from pathlib import Path
import socket
from typing import Any, Callable, Iterable, Mapping
from urllib.parse import urljoin, urlsplit
from urllib.request import HTTPSHandler, HTTPRedirectHandler, ProxyHandler, Request, build_opener


_CATEGORY_QUERIES = (
    ("buggy_code", "software debugging best practices"),
    ("instruction_violation_by_subagents", "agent instruction compliance best practices"),
    ("tool_errors", "tool integration troubleshooting best practices"),
    ("wrong_approach", "software problem solving best practices"),
)
_SAFE_QUERIES = frozenset(query for _, query in _CATEGORY_QUERIES)
_OPEN_TODO = {"status": "open", "message": "Research sources could not be refreshed."}
_MAX_RESPONSE_BYTES = 1024 * 1024
_DEFAULT_SOURCES = {
    "software debugging best practices": ("https://www.nist.gov/itl/ssd/software-quality-group", "NIST Software Quality Group"),
    "agent instruction compliance best practices": ("https://www.nist.gov/itl/ai-risk-management-framework", "NIST AI Risk Management Framework"),
    "tool integration troubleshooting best practices": ("https://www.nist.gov/itl/ssd/software-quality-group", "NIST Software Quality Group"),
    "software problem solving best practices": ("https://www.nist.gov/itl/ssd/software-quality-group", "NIST Software Quality Group"),
}


def _timestamp(now: datetime | None) -> str:
    value = now or datetime.now(timezone.utc)
    if value.tzinfo is None or value.utcoffset() is None:
        raise ValueError("timestamps must be timezone-aware")
    return value.astimezone(timezone.utc).isoformat()


def safe_queries(friction_counts: Mapping[str, Any]) -> list[str]:
    """Return generic, allowlisted queries for recurring friction only."""
    if not isinstance(friction_counts, Mapping):
        return []
    return [
        query
        for category, query in _CATEGORY_QUERIES
        if isinstance(friction_counts.get(category), int)
        and not isinstance(friction_counts.get(category), bool)
        and friction_counts[category] >= 2
    ]


def refresh_sources(
    queries: Iterable[str], search: Callable[[str], Iterable[Mapping[str, Any]]], *, now: datetime | None = None
) -> list[dict[str, str]]:
    """Refresh generic queries, representing lookup failures without raising."""
    checked_at = _timestamp(now)
    sources: list[dict[str, str]] = []
    for query in queries:
        if query not in _SAFE_QUERIES:
            continue
        try:
            entries = search(query)
            for entry in entries:
                if not isinstance(entry, Mapping):
                    continue
                url, title = entry.get("url"), entry.get("title")
                if isinstance(url, str) and isinstance(title, str):
                    sources.append(
                        {"url": url, "title": title, "topic": query, "checked_at": checked_at, "verification": "verified"}
                    )
        except Exception:
            sources.append({"topic": query, "checked_at": checked_at, "verification": "unverified"})
    return sources


def cache_sources(
    cache_path: str | Path,
    friction_counts: Mapping[str, Any],
    search: Callable[[str], Iterable[Mapping[str, Any]]],
    *,
    now: datetime | None = None,
) -> dict[str, list[dict[str, str]]]:
    """Cache only public source metadata; failed lookups create an open todo."""
    found_at = _timestamp(now)
    sources = refresh_sources(safe_queries(friction_counts), search, now=now)
    cached = [
        {
            "url": source["url"],
            "title": source["title"],
            "topic": source["topic"],
            "found_at": found_at,
            "freshness": source["verification"],
            "query": source["topic"],
        }
        for source in sources
        if source["verification"] == "verified"
    ]
    todos = [_OPEN_TODO.copy()] if any(source["verification"] == "unverified" for source in sources) else []
    target = Path(cache_path)
    if todos and target.exists():
        try:
            existing = json.loads(target.read_text(encoding="utf-8"))
        except (OSError, TypeError, ValueError):
            existing = None
        if isinstance(existing, list):
            merged = list(existing)
            seen_urls = {item.get("url") for item in merged if isinstance(item, dict)}
            merged.extend(source for source in cached if source.get("url") not in seen_urls)
            if merged != existing:
                target.write_text(json.dumps(merged, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            return {"sources": merged, "todos": todos}
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(cached, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return {"sources": cached, "todos": todos}


def default_search(query: str) -> list[dict[str, str]]:
    """Optionally verify one generic public source for an allowlisted topic."""
    if os.environ.get("CODEX_INSIGHTS_ENABLE_PUBLIC_RESEARCH", "").casefold() not in {"1", "true", "yes"}:
        return []
    source = _DEFAULT_SOURCES.get(query)
    if source is None:
        return []
    url, title = source
    fetch_url(url)
    return [{"url": url, "title": title, "topic": query}]


def _resolve_host(host: str) -> list[str]:
    return [item[4][0] for item in socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)]


def _validated_destination(url: str, resolver: Callable[[str], Iterable[str]]) -> tuple[str, int, tuple[str, ...]]:
    parsed = urlsplit(url)
    if parsed.scheme != "https" or not parsed.hostname or parsed.username is not None or parsed.password is not None:
        raise ValueError("URL must be a credential-free HTTPS URL with a host")
    try:
        port = parsed.port or 443
    except ValueError as error:
        raise ValueError("URL has an invalid port") from error
    host = parsed.hostname.rstrip(".")
    if host.lower() == "localhost":
        raise ValueError("URL host is not publicly routable")
    try:
        addresses = [str(ipaddress.ip_address(host))]
    except ValueError:
        addresses = list(resolver(host))
    if not addresses:
        raise ValueError("URL host did not resolve")
    try:
        unsafe = any(not ipaddress.ip_address(address).is_global for address in addresses)
    except ValueError as error:
        raise ValueError("URL host resolved to an invalid address") from error
    if unsafe:
        raise ValueError("URL host is not publicly routable")
    return host, port, tuple(addresses)


class _SafeRedirectHandler(HTTPRedirectHandler):
    def __init__(self, resolver: Callable[[str], Iterable[str]]):
        super().__init__()
        self._resolver = resolver

    def redirect_request(self, request, fp, code, msg, headers, newurl):
        _validated_destination(urljoin(request.full_url, newurl), self._resolver)
        return super().redirect_request(request, fp, code, msg, headers, newurl)


class _PinnedHTTPSConnection(HTTPSConnection):
    """HTTPS connection whose TCP peer was vetted before connecting."""

    def __init__(self, host: str, port: int, connect_hosts: tuple[str, ...], **kwargs: Any):
        self.connect_hosts = connect_hosts
        super().__init__(host, port, **kwargs)

    def connect(self) -> None:
        if self._tunnel_host:
            raise ValueError("HTTPS proxies are not supported for pinned requests")
        last_error: OSError | None = None
        for address in self.connect_hosts:
            try:
                self.sock = socket.create_connection((address, self.port), self.timeout, self.source_address)
                break
            except OSError as error:
                last_error = error
        else:
            assert last_error is not None
            raise last_error
        self.sock = self._context.wrap_socket(self.sock, server_hostname=self.host)


class _PinnedHTTPSHandler(HTTPSHandler):
    """Resolve once, validate, then connect directly to the vetted address."""

    def __init__(self, resolver: Callable[[str], Iterable[str]]):
        super().__init__()
        self._resolver = resolver

    def https_open(self, request):
        host, port, addresses = _validated_destination(request.full_url, self._resolver)

        def connection_factory(_request_host: str, **kwargs: Any) -> _PinnedHTTPSConnection:
            return _PinnedHTTPSConnection(host, port, addresses, **kwargs)

        return self.do_open(connection_factory, request, context=self._context)


def fetch_url(
    url: str,
    *,
    opener: Callable[..., Any] | None = None,
    resolver: Callable[[str], Iterable[str]] = _resolve_host,
) -> bytes:
    """Fetch a bounded response from a public HTTPS destination only."""
    request = Request(url, headers={"User-Agent": "Codex-Insights/1.0"})
    if opener is not None:
        _validated_destination(url, resolver)
        open_request = opener
    else:
        open_request = build_opener(ProxyHandler({}), _SafeRedirectHandler(resolver), _PinnedHTTPSHandler(resolver)).open
    with open_request(request, timeout=15) as response:
        body = response.read(_MAX_RESPONSE_BYTES + 1)
    if len(body) > _MAX_RESPONSE_BYTES:
        raise ValueError("response exceeds one megabyte")
    return body
