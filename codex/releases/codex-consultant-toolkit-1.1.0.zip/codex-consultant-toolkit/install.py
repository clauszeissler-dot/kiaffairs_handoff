#!/usr/bin/env python3
"""Interactive installer for the Codex Consultant Toolkit package."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import re
import shutil
import sys
from datetime import datetime, timezone


ROOT = Path(__file__).resolve().parent
SKILLS = ROOT / "skills"
HOOKS = ROOT / "hooks"
INSIGHTS = ROOT / "insights"
AGENTS = ROOT / "agents"

ENGINEERING_SKILLS = {
    "writing-plans", "test-driven-development", "systematic-debugging",
    "verification-before-completion", "requesting-code-review", "receiving-code-review",
}
SECURITY_SKILLS = {"security-best-practices", "security-threat-model"}


def ask(question: str, *, default: bool) -> bool:
    suffix = " [J/n] " if default else " [j/N] "
    value = input(question + suffix).strip().casefold()
    if not value:
        return default
    if value in {"j", "ja", "y", "yes"}:
        return True
    if value in {"n", "nein", "no"}:
        return False
    print("Bitte j oder n eingeben.")
    return ask(question, default=default)


def backup(path: Path) -> None:
    if not path.exists():
        return
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    target = path.with_name(f"{path.name}.toolkit-backup-{stamp}")
    index = 1
    while target.exists():
        target = path.with_name(f"{path.name}.toolkit-backup-{stamp}-{index}")
        index += 1
    shutil.copy2(path, target)
    print(f"Sicherung: {target}")


def copy_component(source: Path, target: Path, *, overwrite: bool) -> bool:
    if target.exists() and not overwrite:
        print(f"Übersprungen (bereits vorhanden): {target}")
        return False
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(source, target, dirs_exist_ok=overwrite)
    print(f"Installiert: {target}")
    return True


def copy_file(source: Path, target: Path, *, overwrite: bool) -> bool:
    if target.exists() and not overwrite:
        print(f"Übersprungen (bereits vorhanden): {target}")
        return False
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    print(f"Installiert: {target}")
    return True


def merge_hook(hooks_path: Path, event: str, group: dict[str, object]) -> None:
    data: dict[str, object] = {"hooks": {}}
    if hooks_path.exists():
        try:
            data = json.loads(hooks_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as error:
            raise RuntimeError(f"Ungültiges JSON in {hooks_path}: {error}") from error
    hooks = data.setdefault("hooks", {})
    if not isinstance(hooks, dict):
        raise RuntimeError(f"Ungültiger hooks-Block in {hooks_path}")
    groups = hooks.setdefault(event, [])
    if not isinstance(groups, list):
        raise RuntimeError(f"Ungültiger {event}-Block in {hooks_path}")
    command = str(group["hooks"][0]["command"])  # type: ignore[index]
    exists = any(
        isinstance(item, dict)
        and any(isinstance(handler, dict) and handler.get("command") == command for handler in item.get("hooks", []))
        for item in groups
    )
    if exists:
        return
    groups.append(group)
    hooks_path.parent.mkdir(parents=True, exist_ok=True)
    backup(hooks_path)
    hooks_path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def configure_compaction(config_path: Path, *, context_window: int, remaining_percent: int, overwrite: bool) -> None:
    if context_window <= 0 or not 1 <= remaining_percent < 100:
        raise ValueError("Kontextfenster muss positiv sein; Restkontext liegt zwischen 1 und 99 Prozent.")
    threshold = context_window * (100 - remaining_percent) // 100
    content = config_path.read_text(encoding="utf-8") if config_path.exists() else ""
    key = re.compile(r"(?m)^model_auto_compact_token_limit\s*=.*$")
    scope = re.compile(r"(?m)^model_auto_compact_token_limit_scope\s*=.*$")
    if key.search(content) and not overwrite:
        print("Bestehende Compaction-Schwelle bleibt unverändert.")
        return
    if config_path.exists():
        backup(config_path)
    if key.search(content):
        content = key.sub(f"model_auto_compact_token_limit = {threshold}", content)
        content = scope.sub('model_auto_compact_token_limit_scope = "total"', content)
    else:
        content += f"\n# Toolkit: Snapshot bei {remaining_percent} % Restkontext\nmodel_auto_compact_token_limit = {threshold}\nmodel_auto_compact_token_limit_scope = \"total\"\n"
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(content, encoding="utf-8")
    print(f"Auto-Compaction: {threshold} Token ({remaining_percent} % Restkontext)")


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument("--codex-home", type=Path, default=Path.home() / ".codex")
    result.add_argument("--handoff", action="store_true", help="Handoff-Skill und Context-Snapshot installieren")
    result.add_argument("--engineering", action="store_true", help="allgemeine Engineering-Skills installieren")
    result.add_argument("--security", action="store_true", help="Security-Skills installieren")
    result.add_argument("--n8n", action="store_true", help="n8n-Skills installieren")
    result.add_argument("--agents", action="store_true", help="Rollenprofile installieren")
    result.add_argument("--insights", action="store_true", help="lokale Insights-Dateien installieren")
    result.add_argument("--configure-compaction", action="store_true", help="Auto-Compaction-Schwelle konfigurieren")
    result.add_argument("--context-window", type=int, help="Kontextfenster des ausgewählten Modells in Tokens")
    result.add_argument("--remaining-context-percent", type=int, default=20)
    result.add_argument("--overwrite", action="store_true", help="vorhandene Toolkit-Dateien und Compaction-Schwelle ersetzen")
    result.add_argument("--yes", action="store_true", help="keine interaktiven Fragen stellen")
    return result


def main(argv: list[str] | None = None) -> int:
    options = parser().parse_args(argv)
    selected = any(getattr(options, name) for name in ("handoff", "engineering", "security", "n8n", "agents", "insights"))
    if not selected and options.yes:
        parser().error("Mit --yes mindestens einen Installationsumfang auswählen.")
    if not selected:
        print("Codex Consultant Toolkit – Installationsumfang auswählen")
        options.handoff = ask("Handoff-Schutz inklusive PreCompact-Snapshot installieren?", default=True)
        options.engineering = ask("Allgemeine Engineering-Skills installieren?", default=True)
        options.security = ask("Security-Skills installieren?", default=False)
        options.n8n = ask("n8n-Skills installieren?", default=False)
        options.agents = ask("Rollenprofile installieren?", default=False)
        options.insights = ask("Lokale Insights-Dateien installieren?", default=False)

    if options.handoff and not options.configure_compaction and not options.yes:
        options.configure_compaction = ask("Auto-Compaction auf eine Restkontext-Schwelle setzen?", default=False)
    if options.configure_compaction and options.context_window is None:
        if options.yes:
            parser().error("--configure-compaction benötigt --context-window.")
        options.context_window = int(input("Kontextfenster des Modells in Tokens (z. B. 272000): ").strip())

    codex_home: Path = options.codex_home.expanduser().resolve()
    overwrite = options.overwrite
    if options.handoff:
        copy_component(SKILLS / "handoff", codex_home / "skills" / "handoff", overwrite=overwrite)
    if options.handoff or options.insights:
        copy_file(HOOKS / "codex_session_hook.py", codex_home / "hooks" / "codex_session_hook.py", overwrite=overwrite)
        merge_hook(codex_home / "hooks.json", "UserPromptSubmit", {
            "hooks": [{"type": "command", "command": f"python3 {codex_home}/hooks/codex_session_hook.py", "timeout": 600, "statusMessage": "Prüfe Insights und Session-Abschluss"}],
        })
    if options.handoff:
        merge_hook(codex_home / "hooks.json", "PreCompact", {
            "matcher": "^auto$",
            "hooks": [{"type": "command", "command": f"bash {codex_home}/skills/handoff/scripts/precompact-handoff.sh", "timeout": 30, "statusMessage": "Sichere Arbeitsstand vor Context-Compaction"}],
        })
    if options.engineering:
        for name in sorted(ENGINEERING_SKILLS):
            copy_component(SKILLS / name, codex_home / "skills" / name, overwrite=overwrite)
    if options.security:
        for name in sorted(SECURITY_SKILLS):
            copy_component(SKILLS / name, codex_home / "skills" / name, overwrite=overwrite)
    if options.n8n:
        for source in sorted(SKILLS.glob("n8n-*")):
            copy_component(source, codex_home / "skills" / source.name, overwrite=overwrite)
    if options.agents:
        for source in sorted(AGENTS.glob("*.toml")):
            copy_file(source, codex_home / "agents" / source.name, overwrite=overwrite)
    if options.insights:
        for source in sorted(INSIGHTS.glob("*.py")):
            copy_file(source, codex_home / "tools" / source.name, overwrite=overwrite)
        profile = codex_home / "insights" / "profile.json"
        if not profile.exists():
            profile.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(ROOT / "insights" / "profile.example.json", profile)
            print(f"Installiert: {profile}")
        print("Insights bleiben deaktiviert, bis CODEX_TOOLKIT_ENABLE_INSIGHTS=1 beim Codex-Start gesetzt ist.")
    if options.configure_compaction:
        configure_compaction(codex_home / "config.toml", context_window=options.context_window, remaining_percent=options.remaining_context_percent, overwrite=overwrite)
    print("Fertig. Starte Codex neu und vertraue neue Hooks einmal über /hooks.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
