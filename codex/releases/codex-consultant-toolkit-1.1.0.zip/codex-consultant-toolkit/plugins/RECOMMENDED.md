# Optionale Plugin-Empfehlungen

Diese Liste ist Dokumentation, keine ausführbare Konfiguration. Vor einer
Installation sind die jeweilige Plugin-Beschreibung und Unternehmensvorgaben zu prüfen.

| Plugin-ID | Zweck | Voraussetzung | Manuelle Aktivierung |
| --- | --- | --- | --- |
| `supabase` | Datenbank- und Backend-Unterstützung | Freigegebenes Projekt | Über den Codex-Plugin-Manager installieren und projektbezogen konfigurieren |
| `vercel` | Deployment- und Next.js-Unterstützung | Freigegebenes Projekt | Über den Plugin-Manager installieren; keine Umgebungswerte in Prompts einfügen |
| `n8n` | Workflow- und Automatisierungsunterstützung | Freigegebene n8n-Instanz | Plugin- bzw. MCP-Konfiguration gemäß n8n-Dokumentation manuell ergänzen |
| `google-drive` | Dokumenten- und Tabellenarbeit | Freigegebene Workspace-Verbindung | Nur nach Freigabe im Connector-Dialog verbinden |
