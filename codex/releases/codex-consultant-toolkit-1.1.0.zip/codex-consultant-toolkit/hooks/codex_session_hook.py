#!/usr/bin/env python3
"""Optional /insights and session-end behavior for one Codex prompt hook."""
import json
import os
from pathlib import Path
import re
import subprocess
import sys

CODEX_HOME = Path(os.environ.get("CODEX_TOOLKIT_HOME", Path.home() / ".codex"))
REPORT_DIR = CODEX_HOME / "insights" / "reports"
GENERATOR = CODEX_HOME / "tools" / "codex_insights.py"
PROFILE = CODEX_HOME / "insights" / "profile.json"
PYTHON = Path(sys.executable)

def insights_enabled() -> bool:
    return os.environ.get("CODEX_TOOLKIT_ENABLE_INSIGHTS", "").casefold() in {"1", "true", "yes"}

def context(message: str) -> None:
    print(json.dumps({"hookSpecificOutput": {"hookEventName": "UserPromptSubmit", "additionalContext": message}}, ensure_ascii=False))

def latest_report() -> Path | None:
    reports = sorted(REPORT_DIR.glob("codex_insights_*.html"), key=lambda path: path.stat().st_mtime, reverse=True)
    return reports[0] if reports else None

def refresh_report(*, force_research_refresh: bool = False, runner=subprocess.run) -> Path | None:
    if not GENERATOR.is_file(): return None
    command = [str(PYTHON), str(GENERATOR), "--active", "--output-dir", str(REPORT_DIR), "--profile", str(PROFILE)]
    if force_research_refresh: command.append("--force-research-refresh")
    try: result = runner(command, capture_output=True, text=True, timeout=600, check=False)
    except (OSError, subprocess.TimeoutExpired): return None
    if result.returncode: return None
    candidate = Path(result.stdout.splitlines()[0]) if result.stdout else None
    return candidate if candidate and candidate.is_file() else latest_report()

def handle_event(event: dict[str, object], *, runner=subprocess.run, emit=context) -> None:
    normalized = " ".join(str(event.get("prompt", "")).casefold().split())
    insights = re.fullmatch(r"/insights(?:\s+(neu|refresh|aktualisieren))?[.!…]*", normalized)
    if insights:
        if not insights_enabled():
            emit("CODEX INSIGHTS: Das optionale Modul ist deaktiviert. Setze CODEX_TOOLKIT_ENABLE_INSIGHTS=1, um es bewusst zu aktivieren.")
            return
        report = refresh_report(force_research_refresh=bool(insights.group(1)), runner=runner)
        emit("CODEX INSIGHTS: Der lokale Bericht liegt bereit." if report else "CODEX INSIGHTS: Der Bericht konnte nicht erzeugt werden.")
        return
    ending = re.compile(r"(?:^|.*\b)(?:ende f(?:ü|u|ue)r heute|f(?:ü|u|ue)r heute (?:reicht(?: es)?|ist (?:schluss|genug))|feierabend|gute nacht|bis (?:morgen|sp(?:ä|a|ae)ter)|wir (?:machen|setzen) (?:morgen|sp(?:ä|a|ae)ter) (?:weiter|fort))[.!…]*$")
    if not ending.fullmatch(normalized): return
    snapshot = CODEX_HOME / "skills" / "handoff" / "scripts" / "precompact-handoff.sh"
    status = "Der Sicherheits-Snapshot konnte nicht gestartet werden."
    if snapshot.is_file():
        try:
            result = runner(["bash", str(snapshot)], cwd=event.get("cwd") or ".", text=True, capture_output=True, timeout=30, check=False)
            status = "Ein minimaler Sicherheits-Snapshot wurde bereits geschrieben." if result.returncode == 0 else "Der Sicherheits-Snapshot ist fehlgeschlagen; erstelle trotzdem das vollständige Handoff."
        except (OSError, subprocess.TimeoutExpired): status = "Der Sicherheits-Snapshot ist fehlgeschlagen; erstelle trotzdem das vollständige Handoff."
    emit("VERBINDLICHER HANDOFF-TRIGGER: Der User beendet die Arbeits-Session. " + status + " Führe jetzt vor jeder abschließenden Antwort den vollständigen Handoff-Skill aus.")

def main() -> int:
    try: event = json.load(sys.stdin)
    except (json.JSONDecodeError, OSError): return 0
    if isinstance(event, dict): handle_event(event)
    return 0

if __name__ == "__main__": raise SystemExit(main())
