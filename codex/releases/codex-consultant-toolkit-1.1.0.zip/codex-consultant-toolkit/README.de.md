# Neutraler Codex Consultant Toolkit

Dieses Paket bündelt neutrale Arbeitsabläufe für Engineering und Automatisierung.
Der interaktive Installer fragt vorab nach dem gewünschten Umfang und installiert
ausschließlich die ausgewählten Komponenten.

## Voraussetzungen

- Codex CLI 0.155.0 oder neuer mit `PreCompact`-Hooks
- Python 3.11 oder neuer für das optionale Insights-Modul
- Optional: eine lokale n8n-Installation für die n8n-Skills

## Interaktive Installation

1. Archiv entpacken und `INVENTORY.md` lesen.
2. Den Installer starten:

   ```sh
   python3 install.py
   ```

   Er fragt einzeln nach Handoff-Schutz, Engineering-, Security- und n8n-Skills,
   Rollenprofilen und lokalen Insights. Bei Handoff kann er zusätzlich eine
   Restkontext-Schwelle für die automatische Compaction setzen.

3. Für eine nicht-interaktive Installation alle gewünschten Komponenten explizit
   angeben, zum Beispiel:

   ```sh
   python3 install.py --yes --handoff --engineering --configure-compaction              --context-window 272000 --remaining-context-percent 20
   ```

4. Codex neu starten und neue Hook-Definitionen einmal über `/hooks` prüfen und
   vertrauen.

## Lokale Insights aktivieren

   ```sh
   export CODEX_TOOLKIT_ENABLE_INSIGHTS=1
   ```

   Öffentliche Recherche bleibt ebenfalls deaktiviert. Nur mit
   `CODEX_INSIGHTS_ENABLE_PUBLIC_RESEARCH=1` sind die wenigen freigegebenen,
   allgemeinen Quellenabrufe erlaubt. Die Variablen müssen in der Umgebung
   gesetzt sein, aus der Codex gestartet wird.

5. Plugin-Empfehlungen in `plugins/RECOMMENDED.md` sind rein manuell.

## Rückbau und Datenschutz

Der Installer erstellt vor jeder Änderung an `hooks.json` oder `config.toml`
eine zeitgestempelte Sicherung. Insights-Daten liegen ausschließlich unter
`~/.codex/insights/` und können nach eigener Sicherung separat gelöscht werden.
Das Paket installiert keinen Hintergrunddienst. Es enthält keine persönlichen
Konfigurationen, Zugänge, Tokens, Projektlisten, Sitzungsdaten, Browserdaten,
Plugin-Caches oder erzeugte Insights-Berichte.
