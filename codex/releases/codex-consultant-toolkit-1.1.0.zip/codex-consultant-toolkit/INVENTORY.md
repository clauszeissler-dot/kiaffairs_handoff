# Inventar und Herkunft

| Modul | Herkunft und Zweck | Bewusst ausgeschlossen |
| --- | --- | --- |
| `skills/` | Kuratierte allgemeine Codex-Skills für Planung, Debugging, Tests, Reviews, Übergaben, Security und n8n | Marken-, Buch-, Musik-, Social-Media- und organisationsspezifische Skills |
| `agents/` | Neutralisierte Rollenprofile für Recherche, Umsetzung und Review | Organisationsnamen, persönliche Pfade und projektspezifische Regeln |
| `hooks/` | Konsolidierter Prompt-Hook für optionales Insights und Session-Ende | ältere Hook-Varianten und vorhandene Hook-Konfiguration |
| `install.py` | Interaktiver, additiver Installer mit Umfangsabfrage | Änderungen ohne Auswahl oder Hook-Vertrauensentscheidung |
| `insights/` | Lokale Analysequellen und Tests | Berichte, Snapshots, Recherche-Caches, Startobjekte und Profildaten |
| `plugins/` | Redaktionelle Empfehlung | Plugin-Code, Marketplace- und Laufzeit-Caches |
| `config/examples/` | Neue Minimalbeispiele | vollständige persönliche Konfigurationen |

`MANIFEST.json` enthält Version, Voraussetzungen, Module und SHA-256-Prüfsummen
aller ausgelieferten Dateien außer dem Manifest selbst.
