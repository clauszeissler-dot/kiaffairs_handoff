#!/usr/bin/env bash
# Minimaler Git-Snapshot als Sicherheitsnetz für den handoff-Skill.
# Aus dem Projekt-Root oder einem Unterordner ausführen.

set -euo pipefail

timestamp="$(date '+%Y%m%d_%H%M%S')"

if project_root="$(git rev-parse --show-toplevel 2>/dev/null)"; then
  cd "$project_root"
else
  project_root="$(pwd)"
fi

output_dir="$project_root/docs/handoffs"
output_file="$output_dir/AUTO_${timestamp}.md"
mkdir -p "$output_dir"

{
  printf '# Auto-Handoff (Sicherheitsnetz) — %s\n\n' "$timestamp"
  printf '> Minimal-Snapshot, automatisch oder manuell vor einer Compaction erzeugt.\n'
  printf '> Kein Ersatz für einen vollständigen `/handoff`-Lauf.\n\n'
  printf '## Projektpfad\n\n`%s`\n\n' "$project_root"
  printf '## Git-Status\n\n```text\n'
  git status --short 2>/dev/null || printf '(kein Git-Repository oder Git nicht verfügbar)\n'
  printf '```\n\n## Letzter Commit\n\n```text\n'
  git log -1 --oneline 2>/dev/null || printf '(kein Commit gefunden)\n'
  printf '```\n\n## Branch\n\n```text\n'
  git branch --show-current 2>/dev/null || printf '(unbekannt)\n'
  printf '```\n\n## Geänderte Dateien gegenüber HEAD\n\n```text\n'
  git diff --name-only HEAD 2>/dev/null || printf '(kein Vergleich möglich)\n'
  printf '```\n'
} > "$output_file"

printf 'Auto-Handoff geschrieben: %s\n' "$output_file"
